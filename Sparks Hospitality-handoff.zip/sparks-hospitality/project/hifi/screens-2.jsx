// Additional hi-fi surfaces: Food Cost, Campaigns, Onboarding/Ross first-run

// ============ FOOD COST ============
function FoodCostHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '220px 1fr', overflow: 'hidden' }}>
      <aside style={{ background: HIFI.bg2, borderRight: `1px solid ${HIFI.line}`, padding: '20px 16px' }}>
        <Logo />
        <div style={{ marginTop: 20 }}>
          {[['Ross','bolt'],['Overview','chart'],['Guests','users'],['Queue','clock'],['Analytics','line'],['Food cost','leaf',true],['Campaigns','send'],['Settings','gear']].map(([l,i,a])=>(
            <div key={l} className={`hf-nav-item ${a?'active':''}`}><Ico n={i} s={15} /> {l}</div>
          ))}
        </div>
      </aside>

      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="hf-eyebrow">Food cost · Ocean Club · last 30 days</div>
            <h1 className="hf-display" style={{ fontSize: 40, margin: '4px 0 0', letterSpacing: '-0.015em' }}>
              Margin is leaking. <span style={{ fontStyle: 'italic', color: HIFI.warn }}>$2,840/week.</span>
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span className="hf-chip"><Ico n="cal" s={12} /> Last 30 days</span>
            <button className="hf-btn ghost sm">Export</button>
            <button className="hf-btn sm"><Ico n="sparkle" s={13} /> Ask Ross</button>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 24 }}>
          {[
            { k: 'COGS', v: '34.1%', d: '+6.1pp', target: '28.0%', warn: true, seed: 9 },
            { k: 'Food spend', v: '$22,840', d: '+$4,120', sub: 'vs. prev 30d', seed: 7 },
            { k: 'Waste', v: '4.8%', d: '+0.9pp', target: '<3%', warn: true, seed: 5 },
            { k: 'Menu margin', v: '52.4%', d: '-3.2pp', sub: 'avg across menu', warn: true, seed: 6 },
          ].map(m=>(
            <div key={m.k} className="hf-card" style={{ padding: 16 }}>
              <div className="hf-eyebrow">{m.k}</div>
              <div className="hf-num" style={{ fontSize: 30, margin: '4px 0 2px', color: m.warn ? HIFI.warn : HIFI.ink }}>{m.v}</div>
              <div className="hf-mono" style={{ fontSize: 11, color: m.warn ? HIFI.warn : HIFI.good }}>{m.d} · {m.target || m.sub}</div>
              <div style={{ marginTop: 10 }}><Sparkline seed={m.seed} color={m.warn ? HIFI.warn : HIFI.ink} h={28} /></div>
            </div>
          ))}
        </div>

        {/* Ross diagnosis card */}
        <div className="hf-card" style={{ padding: 0, marginTop: 14, background: HIFI.ink, color: HIFI.bg, overflow: 'hidden', position: 'relative' }}>
          <div className="hf-grain" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', padding: 24, gap: 32 }}>
            <div>
              <div className="hf-eyebrow" style={{ color: HIFI.accent }}><Ico n="sparkle" s={11} c={HIFI.accent} /> Ross · diagnosis</div>
              <h3 className="hf-display" style={{ fontSize: 28, margin: '8px 0 6px', lineHeight: 1.2 }}>
                Your protein supplier raised prices Apr 18.
              </h3>
              <div style={{ fontSize: 14, lineHeight: 1.6, color: '#c9c4b3' }}>
                Ribeye +12%, duck breast +8%, short rib +6%. Three menu items absorb <b>78%</b> of the impact. Adjusting prices by $2–$4 recovers $2,100/week without hurting volume (Ross' elasticity model).
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
                <button className="hf-btn accent sm">Open menu pricing</button>
                <button className="hf-btn ghost sm" style={{ color: HIFI.bg, borderColor: '#333' }}>See supplier options</button>
              </div>
            </div>
            <div>
              <div className="hf-eyebrow" style={{ color: '#888' }}>Margin impact · weekly</div>
              <LineChart h={140} seed={9} stroke={HIFI.accent} fill={HIFI.accent} />
              <div className="hf-mono" style={{ fontSize: 11, color: '#888', marginTop: 4 }}>
                Solid = actual · dashed = if unchanged (projected -$11k by May)
              </div>
            </div>
          </div>
        </div>

        {/* Menu item table */}
        <div className="hf-card" style={{ padding: 20, marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
            <h3 className="hf-display" style={{ fontSize: 22, margin: 0 }}>Menu · cost drift</h3>
            <div style={{ display: 'flex', gap: 6 }}>
              <span className="hf-chip solid">Drifting</span>
              <span className="hf-chip">Stable</span>
              <span className="hf-chip">All 48</span>
            </div>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${HIFI.ink}`, textAlign: 'left' }}>
                {['Item','Category','Plate cost','Price','Margin','Drift 30d','Volume','Ross'].map(h=>(
                  <th key={h} className="hf-eyebrow" style={{ padding: '10px 8px', fontWeight: 400 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ['Ribeye 12oz', 'Mains', '$18.40', '$48.00', '61.7%', '-4.2pp', '318', 'Reprice +$3'],
                ['Duck confit', 'Mains', '$11.20', '$34.00', '67.1%', '-2.8pp', '412', 'Reprice +$2'],
                ['Short rib', 'Mains', '$14.80', '$42.00', '64.8%', '-2.1pp', '142', 'Swap cut'],
                ['Caesar', 'Starters', '$3.40', '$14.00', '75.7%', '+0.2pp', '251', '—'],
                ['Oysters (6)', 'Raw', '$9.60', '$22.00', '56.4%', '-0.4pp', '202', '—'],
                ['House burger', 'Mains', '$6.80', '$21.00', '67.6%', '-0.6pp', '289', '—'],
              ].map((r, i)=>{
                const drift = parseFloat(r[5]);
                const bad = drift < -1.5;
                return (
                  <tr key={i} style={{ borderBottom: `1px solid ${HIFI.line}` }}>
                    <td style={{ padding: '12px 8px', fontWeight: 500 }}>{r[0]}</td>
                    <td style={{ padding: '12px 8px', color: HIFI.muted }}>{r[1]}</td>
                    <td style={{ padding: '12px 8px', fontFamily: HIFI.font.mono }}>{r[2]}</td>
                    <td style={{ padding: '12px 8px', fontFamily: HIFI.font.mono }}>{r[3]}</td>
                    <td style={{ padding: '12px 8px', fontFamily: HIFI.font.mono }}>{r[4]}</td>
                    <td style={{ padding: '12px 8px', fontFamily: HIFI.font.mono, color: bad ? HIFI.warn : drift > 0 ? HIFI.good : HIFI.muted }}>{r[5]}</td>
                    <td style={{ padding: '12px 8px', fontFamily: HIFI.font.mono, color: HIFI.muted }}>{r[6]}</td>
                    <td style={{ padding: '12px 8px' }}>
                      {r[7] !== '—' ? (
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: HIFI.accent2, fontSize: 12, fontFamily: HIFI.font.mono }}>
                          <Ico n="sparkle" s={11} c={HIFI.accent2} /> {r[7]}
                        </span>
                      ) : <span style={{ color: HIFI.muted }}>—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Stock row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
          <div className="hf-card" style={{ padding: 20 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Stock runway</h3>
            <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginBottom: 12 }}>Days until reorder needed</div>
            {[
              ['Olive oil · 5L', 2, HIFI.warn],
              ['Duck breast', 4, HIFI.warn],
              ['Ribeye', 6, HIFI.accent],
              ['Romaine', 9, HIFI.ink],
              ['House wine · red', 14, HIFI.ink],
            ].map(([n,d,c])=>(
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: `1px solid ${HIFI.line}` }}>
                <div style={{ flex: 1, fontSize: 13 }}>{n}</div>
                <div style={{ width: 120, height: 5, background: HIFI.line, borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(d/14*100, 100)}%`, height: '100%', background: c }} />
                </div>
                <div className="hf-num" style={{ fontSize: 14, width: 60, textAlign: 'right', color: c }}>{d}d</div>
              </div>
            ))}
          </div>
          <div className="hf-card" style={{ padding: 20 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Waste log · 7 days</h3>
            <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginBottom: 12 }}>By category · $ cost</div>
            <BarChart h={120} seed={5} count={7} accent={2} accentColor={HIFI.warn} />
            <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 4, display: 'flex', justifyContent: 'space-between' }}>
              {['Wed','Thu','Fri','Sat','Sun','Mon','Tue'].map(d=><span key={d}>{d}</span>)}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// ============ CAMPAIGNS ============
function CampaignsHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '220px 1fr', overflow: 'hidden' }}>
      <aside style={{ background: HIFI.bg2, borderRight: `1px solid ${HIFI.line}`, padding: '20px 16px' }}>
        <Logo />
        <div style={{ marginTop: 20 }}>
          {[['Ross','bolt'],['Overview','chart'],['Guests','users'],['Queue','clock'],['Analytics','line'],['Food cost','leaf'],['Campaigns','send',true],['Settings','gear']].map(([l,i,a])=>(
            <div key={l} className={`hf-nav-item ${a?'active':''}`}><Ico n={i} s={15} /> {l}</div>
          ))}
        </div>
      </aside>

      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="hf-eyebrow">Campaigns · drafted by Ross</div>
            <h1 className="hf-display" style={{ fontSize: 40, margin: '4px 0 0', letterSpacing: '-0.015em' }}>Win back your VIPs.</h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="hf-btn ghost sm">Discard</button>
            <button className="hf-btn sm">Save draft</button>
            <button className="hf-btn sm"><Ico n="send" s={13} /> Review & send</button>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 20, marginTop: 24 }}>
          {/* Composition area */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {/* Audience */}
            <div className="hf-card" style={{ padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div className="hf-eyebrow">01 · Audience</div>
                <a style={{ fontSize: 11, color: HIFI.accent2, fontFamily: HIFI.font.mono }}>edit segment</a>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
                <div className="hf-num" style={{ fontSize: 44 }}>42</div>
                <div>
                  <div className="hf-display" style={{ fontSize: 20 }}>Lapsed VIPs</div>
                  <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Visits ≥ 5 · Last visit &gt; 90 days · LTV &gt; $1,500</div>
                </div>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                  {'EFJRMKSHLBAPRNIO'.match(/.{1,2}/g).slice(0,6).map(i=>(<Avatar key={i} initials={i} size={28} />))}
                  <span className="hf-chip" style={{ alignSelf: 'center' }}>+36</span>
                </div>
              </div>
            </div>

            {/* Message */}
            <div className="hf-card" style={{ padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div className="hf-eyebrow">02 · Message · Email</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <span className="hf-chip solid">Email</span>
                  <span className="hf-chip">SMS</span>
                  <span className="hf-chip">WhatsApp</span>
                </div>
              </div>

              <div style={{ marginTop: 14, border: `1px solid ${HIFI.line}`, borderRadius: 6, padding: '20px 24px', background: HIFI.bg }}>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>Subject</div>
                <div className="hf-display" style={{ fontSize: 24, margin: '2px 0 16px', letterSpacing: '-0.01em' }}>
                  <span style={{ color: HIFI.accent2, background: HIFI.accent + '22', padding: '0 4px', borderRadius: 2 }}>{'{First name}'}</span>, we saved you a seat.
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.7, color: HIFI.ink2, fontFamily: "'Instrument Serif', serif" }}>
                  <p style={{ margin: '0 0 12px' }}>It's been a while since we poured a glass with you at Ocean Club. Chef Marco just finished the spring menu, and there's a natural-wine tasting on <b>April 28</b> that felt like it had your name on it.</p>
                  <p style={{ margin: '0 0 12px' }}>Six pairings, a small room, 28 seats. We'd love to hold one for you.</p>
                  <p style={{ margin: 0, fontStyle: 'italic', color: HIFI.muted }}>— Marco and the Ocean Club team</p>
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
                  <button className="hf-btn sm">Reserve my seat →</button>
                  <button className="hf-btn ghost sm">See the menu</button>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <span className="hf-chip"><Ico n="sparkle" s={11} /> Personalize further</span>
                <span className="hf-chip"><Ico n="sparkle" s={11} /> Shorten</span>
                <span className="hf-chip"><Ico n="sparkle" s={11} /> Translate</span>
                <span className="hf-chip">A/B test subject</span>
              </div>
            </div>

            {/* Timing */}
            <div className="hf-card" style={{ padding: 20 }}>
              <div className="hf-eyebrow">03 · Timing</div>
              <div style={{ display: 'flex', gap: 20, marginTop: 10, alignItems: 'center' }}>
                <div>
                  <div className="hf-display" style={{ fontSize: 22 }}>Thursday · 9:20 AM</div>
                  <div className="hf-mono" style={{ fontSize: 11, color: HIFI.good }}>↑ 38% projected open · Ross-optimal window</div>
                </div>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
                  <span className="hf-chip accent"><Ico n="sparkle" s={11} /> Ross pick</span>
                  <span className="hf-chip">Custom</span>
                  <span className="hf-chip">Send now</span>
                </div>
              </div>
            </div>
          </div>

          {/* Preview / stats rail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="hf-card" style={{ padding: 20 }}>
              <div className="hf-eyebrow">Projected impact</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 10 }}>
                <div>
                  <div className="hf-num" style={{ fontSize: 28 }}>38%</div>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>open rate</div>
                </div>
                <div>
                  <div className="hf-num" style={{ fontSize: 28 }}>16</div>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>likely responses</div>
                </div>
                <div>
                  <div className="hf-num" style={{ fontSize: 28 }}>12</div>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>expected bookings</div>
                </div>
                <div>
                  <div className="hf-num" style={{ fontSize: 28, color: HIFI.good }}>$5.2k</div>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>projected revenue</div>
                </div>
              </div>
            </div>

            <div className="hf-card" style={{ padding: 20, background: HIFI.ink, color: HIFI.bg, position: 'relative', overflow: 'hidden' }}>
              <div className="hf-grain" />
              <div className="hf-eyebrow" style={{ color: HIFI.accent }}><Ico n="sparkle" s={11} c={HIFI.accent} /> Ross notes</div>
              <ul style={{ margin: '10px 0 0', paddingLeft: 18, fontSize: 13, lineHeight: 1.6, color: '#ddd' }}>
                <li>14 of 42 have wine-pairing attach &gt; 70%</li>
                <li>8 celebrated birthdays in the last 60d — tone should feel personal, not promotional</li>
                <li>Avoid Mondays — this cohort opens 22% less</li>
              </ul>
            </div>

            <div className="hf-card" style={{ padding: 20 }}>
              <div className="hf-eyebrow">Recent campaigns</div>
              <div style={{ marginTop: 10 }}>
                {[
                  ['Spring menu launch', '312 sent', '44% · $8.1k', HIFI.good],
                  ['Easter brunch', '186 sent', '29% · $2.4k', HIFI.ink],
                  ['Wine club recruit', '94 sent', '18% · $920', HIFI.warn],
                ].map(([n, s, r, c])=>(
                  <div key={n} style={{ display: 'flex', gap: 10, padding: '10px 0', borderBottom: `1px solid ${HIFI.line}`, alignItems: 'center' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13 }}>{n}</div>
                      <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{s}</div>
                    </div>
                    <div className="hf-mono" style={{ fontSize: 11, color: c }}>{r}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// ============ RECEIPTS / OPS INBOX ============
function ReceiptsHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '220px 360px 1fr', overflow: 'hidden' }}>
      <aside style={{ background: HIFI.bg2, borderRight: `1px solid ${HIFI.line}`, padding: '20px 16px' }}>
        <Logo />
        <div style={{ marginTop: 20 }}>
          {[['Ross','bolt'],['Overview','chart'],['Guests','users'],['Queue','clock'],['Analytics','line'],['Food cost','leaf'],['Receipts','cart',true],['Campaigns','send'],['Settings','gear']].map(([l,i,a])=>(
            <div key={l} className={`hf-nav-item ${a?'active':''}`}><Ico n={i} s={15} /> {l}</div>
          ))}
        </div>
      </aside>

      {/* Receipt inbox */}
      <section style={{ borderRight: `1px solid ${HIFI.line}`, background: HIFI.paper, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '18px 20px', borderBottom: `1px solid ${HIFI.line}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h2 className="hf-display" style={{ fontSize: 22, margin: 0 }}>Receipts</h2>
            <span className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>12 pending</span>
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            <span className="hf-chip solid">Pending</span>
            <span className="hf-chip">Matched</span>
            <span className="hf-chip">Flagged</span>
            <span className="hf-chip">All</span>
          </div>
        </div>
        <div style={{ overflow: 'auto', flex: 1 }}>
          {[
            { s: 'Sysco Produce', d: 'Apr 22 · 7:12 AM', a: '$1,842.20', t: 'invoice', flag: false, sel: true },
            { s: 'Chef Marco', d: 'Apr 21 · 10:04 PM', a: '$142.80', t: 'petty cash', flag: false },
            { s: 'Pacific Wines', d: 'Apr 21 · 3:40 PM', a: '$3,240.00', t: 'invoice', flag: true },
            { s: 'Uber · delivery', d: 'Apr 21 · 11:16 AM', a: '$32.40', t: 'receipt', flag: false },
            { s: 'Premium Meats', d: 'Apr 20 · 8:22 AM', a: '$2,104.60', t: 'invoice', flag: true },
            { s: 'Whole Foods', d: 'Apr 20 · 7:04 AM', a: '$186.12', t: 'receipt', flag: false },
          ].map((r,i)=>(
            <div key={i} style={{
              padding: '14px 20px', borderBottom: `1px solid ${HIFI.line}`,
              background: r.sel ? HIFI.bg2 : 'transparent',
              borderLeft: `2px solid ${r.sel ? HIFI.ink : 'transparent'}`,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div style={{ fontSize: 14, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6 }}>
                  {r.flag && <span className="hf-dot" style={{ background: HIFI.warn }} />}
                  {r.s}
                </div>
                <div className="hf-num" style={{ fontSize: 15 }}>{r.a}</div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{r.d}</div>
                <span className="hf-chip" style={{ fontSize: 10, padding: '1px 6px' }}>{r.t}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Receipt detail */}
      <main style={{ overflow: 'auto', padding: '24px 32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div className="hf-eyebrow">Invoice · received via WhatsApp · Apr 22 · 7:12 AM</div>
            <h1 className="hf-display" style={{ fontSize: 32, margin: '4px 0 0' }}>Sysco Produce <span style={{ color: HIFI.muted, fontStyle: 'italic', fontSize: 24 }}>— $1,842.20</span></h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="hf-btn ghost sm">Flag</button>
            <button className="hf-btn ghost sm">Edit</button>
            <button className="hf-btn sm"><Ico n="check" s={13} /> Approve & file</button>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 24 }}>
          {/* Receipt image */}
          <div>
            <div style={{ background: HIFI.paper, border: `1px solid ${HIFI.line}`, borderRadius: 6, overflow: 'hidden', aspectRatio: '3/4' }}>
              <div style={{
                height: '100%',
                background: 'repeating-linear-gradient(180deg, #fbf9f3 0 22px, #f2ecd8 22px 23px)',
                padding: 30, position: 'relative',
              }}>
                <div className="hf-mono" style={{ fontSize: 12, color: HIFI.ink, textAlign: 'center', letterSpacing: '0.1em' }}>SYSCO PRODUCE CO.</div>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, textAlign: 'center', marginTop: 4 }}>INV-2026-04-0842 · Apr 22, 2026</div>
                <div style={{ marginTop: 20, fontSize: 11, color: HIFI.ink2, lineHeight: 1.8, fontFamily: HIFI.font.mono }}>
                  {[
                    ['Romaine · 12 cs', '$142.80'],
                    ['Baby arugula · 8 lb', '$64.00'],
                    ['Tomato roma · 40 lb', '$180.00'],
                    ['Onion yellow · 50 lb', '$112.50'],
                    ['Avocado · 60 ct', '$210.00'],
                    ['Lemon · 120 ct', '$96.00'],
                    ['Herbs, mixed · 24 bn', '$168.00'],
                    ['Mushroom, button · 20 lb', '$140.00'],
                    ['...', '...'],
                  ].map(([l,p],i)=>(
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: i<8 ? '1px dashed ' + HIFI.line2 : 'none', padding: '4px 0' }}>
                      <span>{l}</span><span>{p}</span>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 14, borderTop: '2px solid ' + HIFI.ink, paddingTop: 8, display: 'flex', justifyContent: 'space-between', fontFamily: HIFI.font.mono, fontSize: 12 }}>
                  <span>TOTAL</span><span>$1,842.20</span>
                </div>
              </div>
            </div>
          </div>

          {/* Extracted & categorized */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="hf-card" style={{ padding: 18 }}>
              <div className="hf-eyebrow"><Ico n="sparkle" s={11} c={HIFI.accent2} /> Ross extracted</div>
              <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: '10px 16px', marginTop: 12, fontSize: 13 }}>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Vendor</div><div>Sysco Produce Co.</div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Invoice #</div><div>INV-2026-04-0842</div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Date</div><div>Apr 22, 2026</div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Due</div><div>May 6, 2026 · Net 14</div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Venue</div><div>Ocean Club</div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>Category</div><div>Produce <span className="hf-chip" style={{ marginLeft: 6, fontSize: 10 }}>change</span></div>
                <div className="hf-mono" style={{ color: HIFI.muted }}>GL code</div><div>5100 · Food — Produce</div>
              </div>
            </div>

            <div className="hf-card" style={{ padding: 18, borderColor: HIFI.accent + '55', background: '#fcf7e7' }}>
              <div className="hf-eyebrow" style={{ color: HIFI.accent2 }}><Ico n="sparkle" s={11} c={HIFI.accent2} /> Ross noticed</div>
              <div style={{ fontSize: 13.5, marginTop: 8, lineHeight: 1.55, color: HIFI.ink2 }}>
                Tomato roma is <b>$4.50/lb</b> this week, up from <b>$3.20/lb</b> two weeks ago. That's a 40% jump. Consider swapping to canned for sauces until prices settle (est. save $180/wk).
              </div>
              <button className="hf-btn sm" style={{ marginTop: 10 }}>Compare vendors</button>
            </div>

            <div className="hf-card" style={{ padding: 18 }}>
              <div className="hf-eyebrow">Matching</div>
              <div style={{ marginTop: 10, padding: 12, background: HIFI.bg, borderRadius: 4, display: 'flex', alignItems: 'center', gap: 10 }}>
                <Ico n="check" s={16} c={HIFI.good} />
                <div style={{ flex: 1, fontSize: 13 }}>
                  Matched to PO <b>#2026-0418</b>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 2 }}>99.4% confidence · 18 of 18 line items</div>
                </div>
                <a style={{ fontSize: 11, color: HIFI.accent2, fontFamily: HIFI.font.mono }}>view PO →</a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// ============ ONBOARDING / ROSS FIRST RUN ============
function OnboardingHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', background: HIFI.ink, color: HIFI.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', position: 'relative' }}>
      <div className="hf-grain" style={{ opacity: 0.08 }} />
      {/* ambient amber gradient */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 20% 30%, ${HIFI.accent}33, transparent 50%), radial-gradient(circle at 80% 70%, ${HIFI.accent}15, transparent 45%)`,
      }} />

      <div style={{ width: 720, padding: 48, position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Logo size={22} color={HIFI.bg} />
          <span className="hf-mono" style={{ fontSize: 10, color: '#888', letterSpacing: '0.14em', marginLeft: 'auto' }}>STEP 3 OF 5 · RESTAURANT SETUP</span>
        </div>

        <div style={{ marginTop: 56 }}>
          <div className="hf-eyebrow" style={{ color: HIFI.accent }}><Ico n="sparkle" s={11} c={HIFI.accent} /> Hi, I'm Ross.</div>
          <h1 className="hf-display" style={{ fontSize: 64, lineHeight: 1, margin: '14px 0 18px', letterSpacing: '-0.025em' }}>
            I've been learning your restaurants<br/>
            <span style={{ fontStyle: 'italic', color: '#d6cfbd' }}>for the last 14 minutes.</span>
          </h1>
          <div style={{ fontSize: 17, lineHeight: 1.6, color: '#c9c4b3', maxWidth: 560 }}>
            I've read 18,400 receipts, 22,100 guest visits, and 3 years of service history across your four venues. Here's what I found that surprised me.
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, marginTop: 40 }}>
          {[
            { n: '01', t: 'Tuesday dinner is quietly your best-margin service.', c: HIFI.accent },
            { n: '02', t: '28 of your guests visit weekly but have never been recognized.', c: HIFI.bg },
            { n: '03', t: 'Your patio revenue has tripled in 18 months — nobody mentioned it.', c: HIFI.bg },
          ].map(s=>(
            <div key={s.n} style={{ paddingTop: 12, borderTop: `1px solid ${s.c === HIFI.accent ? HIFI.accent : '#444'}` }}>
              <div className="hf-mono" style={{ fontSize: 10, color: s.c, letterSpacing: '0.14em' }}>{s.n}</div>
              <div style={{ fontSize: 15, marginTop: 8, lineHeight: 1.4, color: s.c === HIFI.accent ? HIFI.accent : '#e8e3d5' }}>{s.t}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 48 }}>
          <button className="hf-btn accent" style={{ padding: '12px 24px', fontSize: 15 }}>
            Show me everything <Ico n="arrow" s={14} />
          </button>
          <button className="hf-btn ghost" style={{ color: HIFI.bg, borderColor: '#444', padding: '12px 20px' }}>
            Take the tour first
          </button>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
            {[0,1,2,3,4].map(i=>(
              <div key={i} style={{ width: 24, height: 2, background: i <= 2 ? HIFI.accent : '#333' }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { FoodCostHiFi, CampaignsHiFi, ReceiptsHiFi, OnboardingHiFi });
