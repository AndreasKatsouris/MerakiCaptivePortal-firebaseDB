// Hi-fi ROSS home — editorial concierge
function RossHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '220px 1fr 340px', overflow: 'hidden' }}>
      {/* Sidebar */}
      <aside style={{ background: HIFI.bg2, borderRight: `1px solid ${HIFI.line}`, padding: '20px 16px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Logo />
        <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 4, marginBottom: 20, paddingLeft: 28 }}>Group HQ · 4 venues</div>
        <div className="hf-eyebrow" style={{ padding: '8px 10px 4px' }}>Today</div>
        {[
          ['Ross', 'bolt', true],
          ['Overview', 'chart'],
          ['Queue', 'clock'],
        ].map(([l, i, a]) => (
          <div key={l} className={`hf-nav-item ${a ? 'active' : ''}`}>
            <Ico n={i} s={15} /> {l}
          </div>
        ))}
        <div className="hf-eyebrow" style={{ padding: '16px 10px 4px' }}>Guests</div>
        {[['Profiles','user'],['Segments','users'],['Campaigns','send']].map(([l,i])=>(
          <div key={l} className="hf-nav-item"><Ico n={i} s={15} /> {l}</div>
        ))}
        <div className="hf-eyebrow" style={{ padding: '16px 10px 4px' }}>Operations</div>
        {[['Analytics','line'],['Food cost','leaf'],['Receipts','cart'],['Forecasting','sparkle']].map(([l,i])=>(
          <div key={l} className="hf-nav-item"><Ico n={i} s={15} /> {l}</div>
        ))}
        <div style={{ marginTop: 'auto', paddingTop: 16, borderTop: `1px solid ${HIFI.line}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px' }}>
            <Avatar initials="MA" size={28} />
            <div style={{ fontSize: 12, flex: 1 }}>
              <div>Maya Alvarez</div>
              <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>Group Ops</div>
            </div>
            <Ico n="gear" s={14} c={HIFI.muted} />
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ overflow: 'auto', padding: '32px 40px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div className="hf-eyebrow">Tuesday · April 22 · 9:14 AM</div>
            <h1 className="hf-display" style={{ fontSize: 52, lineHeight: 1, margin: '6px 0 8px', maxWidth: 620, letterSpacing: '-0.02em' }}>
              Good morning, Maya.<br />
              <span style={{ color: HIFI.muted, fontStyle: 'italic' }}>Three things worth your attention.</span>
            </h1>
            <div style={{ fontSize: 14, color: HIFI.ink2, maxWidth: 520, lineHeight: 1.5 }}>
              Ross watched 14,200 signals across your four venues overnight. Here's what changed while you slept.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="hf-btn ghost"><Ico n="cal" s={14} /> Tue, Apr 22</button>
            <button className="hf-btn"><Ico n="sparkle" s={14} /> Ask Ross</button>
          </div>
        </div>

        {/* The three cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 32 }}>
          {/* Urgent */}
          <div className="hf-card" style={{ padding: 0, overflow: 'hidden', borderColor: HIFI.warn + '55' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px', gap: 0 }}>
              <div style={{ padding: '20px 24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className="hf-chip warn"><span className="hf-dot" style={{ background: HIFI.warn }} /> Needs attention</span>
                  <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Ocean Club · 3 days running</span>
                </div>
                <h3 className="hf-display" style={{ fontSize: 26, margin: '10px 0 6px', lineHeight: 1.15 }}>
                  Food cost climbed to 34.1%, 6 points above target.
                </h3>
                <div style={{ fontSize: 13.5, color: HIFI.ink2, lineHeight: 1.55, maxWidth: 480 }}>
                  The protein line is the culprit — specifically ribeye and duck. Your supplier raised prices on Apr&nbsp;18; the menu hasn't adjusted. Est. margin loss: <b>$2,840/week</b>.
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16, alignItems: 'center' }}>
                  <button className="hf-btn">Open food-cost brief <Ico n="arrow" s={13} /></button>
                  <button className="hf-btn ghost">Ask Ross why</button>
                  <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginLeft: 'auto' }}>2 suggested actions</span>
                </div>
              </div>
              <div style={{ background: HIFI.bg2, padding: 18, borderLeft: `1px solid ${HIFI.line}`, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div className="hf-eyebrow">7-day COGS</div>
                <div className="hf-num" style={{ fontSize: 38, color: HIFI.warn }}>34.1<span style={{ fontSize: 20, color: HIFI.muted }}>%</span></div>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginBottom: 6 }}>target 28.0%</div>
                <LineChart h={46} seed={9} stroke={HIFI.warn} fill={HIFI.warn} />
              </div>
            </div>
          </div>

          {/* Guest */}
          <div className="hf-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px' }}>
              <div style={{ padding: '20px 24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className="hf-chip"><Ico n="users" s={12} /> Guest intelligence</span>
                  <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>42 guests · $2,180 avg LTV</span>
                </div>
                <h3 className="hf-display" style={{ fontSize: 26, margin: '10px 0 6px' }}>
                  Your most valuable guests are slipping away.
                </h3>
                <div style={{ fontSize: 13.5, color: HIFI.ink2, lineHeight: 1.55, maxWidth: 500 }}>
                  42 VIPs haven't returned in 90+ days. Ross drafted a personalized win-back — a wine tasting at Ocean Club. Projected response: 38%.
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  <button className="hf-btn">Review draft campaign</button>
                  <button className="hf-btn ghost">See all 42 guests</button>
                </div>
              </div>
              <div style={{ background: HIFI.bg2, padding: 18, borderLeft: `1px solid ${HIFI.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Donut size={110} pct={0.28} color={HIFI.accent} label="28%" sub="return rate" />
              </div>
            </div>
          </div>

          {/* Win */}
          <div className="hf-card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px' }}>
              <div style={{ padding: '20px 24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className="hf-chip good"><Ico n="check" s={12} /> Trending up</span>
                  <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Weekend · +$6,240 vs. LW</span>
                </div>
                <h3 className="hf-display" style={{ fontSize: 26, margin: '10px 0 6px' }}>
                  The patio promotion is working — extend it?
                </h3>
                <div style={{ fontSize: 13.5, color: HIFI.ink2, lineHeight: 1.55, maxWidth: 500 }}>
                  Saturday beat forecast by 18%. Weather plus the promo compounded. Ross suggests extending two weeks and expanding to The Vault.
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  <button className="hf-btn">Extend promotion</button>
                  <button className="hf-btn ghost">See breakdown</button>
                </div>
              </div>
              <div style={{ background: HIFI.bg2, padding: 18, borderLeft: `1px solid ${HIFI.line}`, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div className="hf-eyebrow">Sat revenue</div>
                <div className="hf-num" style={{ fontSize: 34 }}>$16,240</div>
                <div style={{ fontSize: 11, color: HIFI.good, fontFamily: HIFI.font.mono }}>↑ $2,480 vs. LW</div>
                <BarChart h={46} seed={3} count={12} accent={10} accentColor={HIFI.accent} />
              </div>
            </div>
          </div>
        </div>

        {/* Quick jump */}
        <div style={{ marginTop: 28, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <div className="hf-eyebrow">Or jump to</div>
          {['Tonight\'s bookings','Menu performance','Staff schedule','Receipts queue','Compliance'].map(x=>(
            <span key={x} className="hf-chip">{x}</span>
          ))}
        </div>
      </main>

      {/* Right rail */}
      <aside style={{ borderLeft: `1px solid ${HIFI.line}`, padding: '24px 20px', background: HIFI.paper, overflow: 'auto' }}>
        {/* Ask Ross */}
        <div style={{ background: HIFI.ink, color: HIFI.bg, padding: 18, borderRadius: 6, position: 'relative', overflow: 'hidden' }}>
          <div className="hf-grain" />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Ico n="sparkle" s={14} c={HIFI.accent} />
            <span className="hf-mono" style={{ fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#aaa' }}>Ask Ross</span>
            <span className="hf-kbd" style={{ marginLeft: 'auto', color: '#bbb', borderColor: '#333' }}>⌘K</span>
          </div>
          <div className="hf-display" style={{ fontSize: 18, lineHeight: 1.25, fontStyle: 'italic', color: HIFI.bg }}>
            "How did my Saturday brunch compare to last month?"
          </div>
          <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid #2a2620' }}>
            <div className="hf-mono" style={{ fontSize: 10, color: '#888', marginBottom: 6 }}>recent answers</div>
            {['↑ 22% covers vs. last Sat','Avg check held at $48','Waitlist peaked at 43 min'].map(x=>(
              <div key={x} style={{ fontSize: 12.5, padding: '3px 0', color: '#ddd' }}>{x}</div>
            ))}
          </div>
        </div>

        {/* Live venues */}
        <div style={{ marginTop: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div className="hf-eyebrow">Live · all venues</div>
            <span className="hf-mono" style={{ fontSize: 10, color: HIFI.good }}>● updated 2s ago</span>
          </div>
          <div style={{ marginTop: 8 }}>
            {[
              ['Ocean Club', 'open', '64 covers', '18m wait', HIFI.good, 7],
              ['The Vault', 'open', '38 covers', '6m wait', HIFI.good, 9],
              ['Corner Café', 'setting up', 'opens 11:00', '—', HIFI.accent, 0],
              ['Rooftop 21', 'closed', 'Thu 5:00 PM', '—', HIFI.muted, 0],
            ].map(([n, s, a, b, c, sd]) => (
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: `1px solid ${HIFI.line}` }}>
                <span className="hf-dot" style={{ background: c, boxShadow: `0 0 0 3px ${c}22` }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{n}</div>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{a} · {b}</div>
                </div>
                {sd > 0 && <div style={{ width: 54 }}><Sparkline seed={sd} color={c} h={18} /></div>}
              </div>
            ))}
          </div>
        </div>

        {/* Ross suggests */}
        <div style={{ marginTop: 24 }}>
          <div className="hf-eyebrow">Ross suggests</div>
          <div style={{ marginTop: 8 }}>
            {[
              ['87 guests celebrate birthdays this week','Draft outreach'],
              ['Olive oil runs out in 2 days','Reorder now'],
              ['Sat 6–8pm schedule gap at Ocean Club','Fill shift'],
            ].map(([t, a]) => (
              <div key={t} className="hf-card" style={{ padding: 12, marginBottom: 8, background: HIFI.bg }}>
                <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>{t}</div>
                <a style={{ fontSize: 11, color: HIFI.accent2, textDecoration: 'none', fontFamily: HIFI.font.mono, marginTop: 4, display: 'inline-block' }}>{a} →</a>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

// Hi-fi Dashboard
function DashHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '220px 1fr', overflow: 'hidden' }}>
      <aside style={{ background: HIFI.bg2, borderRight: `1px solid ${HIFI.line}`, padding: '20px 16px' }}>
        <Logo />
        <div style={{ marginTop: 20 }}>
          {[['Ross','bolt'],['Overview','chart',true],['Guests','users'],['Queue','clock'],['Analytics','line'],['Food cost','leaf'],['Campaigns','send'],['Settings','gear']].map(([l,i,a])=>(
            <div key={l} className={`hf-nav-item ${a?'active':''}`}><Ico n={i} s={15} /> {l}</div>
          ))}
        </div>
      </aside>

      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="hf-eyebrow">Tuesday · April 22</div>
            <h1 className="hf-display" style={{ fontSize: 40, margin: '4px 0 0', letterSpacing: '-0.015em' }}>Group overview</h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span className="hf-chip"><Ico n="filter" s={12} /> All venues</span>
            <span className="hf-chip"><Ico n="cal" s={12} /> Today</span>
            <button className="hf-btn ghost sm">Export</button>
            <button className="hf-btn sm"><Ico n="sparkle" s={13} /> Ask Ross</button>
          </div>
        </div>

        {/* Metrics */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 24 }}>
          {[
            { k: 'Revenue', v: '$12,480', d: '+8.2%', good: true, chart: 1 },
            { k: 'Covers', v: '316', d: '+12', good: true, chart: 2 },
            { k: 'Avg check', v: '$39.50', d: '-$1.20', good: false, chart: 3 },
            { k: 'Food cost', v: '31.4%', d: '+3.4pp', good: false, chart: 4 },
          ].map(m => (
            <div key={m.k} className="hf-card" style={{ padding: 16 }}>
              <div className="hf-eyebrow">{m.k}</div>
              <div className="hf-num" style={{ fontSize: 32, margin: '4px 0 2px' }}>{m.v}</div>
              <div className="hf-mono" style={{ fontSize: 11, color: m.good ? HIFI.good : HIFI.warn }}>
                {m.good ? '↑' : '↓'} {m.d} vs. yesterday
              </div>
              <div style={{ marginTop: 10 }}>
                <Sparkline seed={m.chart} color={m.good ? HIFI.good : HIFI.warn} h={30} />
              </div>
            </div>
          ))}
        </div>

        {/* Main chart + top performers */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, marginTop: 14 }}>
          <div className="hf-card" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <h3 className="hf-display" style={{ fontSize: 22, margin: 0 }}>Revenue · 30 days</h3>
                <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>vs. previous 30 days</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['D','W','M','Q'].map((x,i)=>(<span key={x} className={`hf-chip ${i===2?'solid':''}`} style={{ padding: '2px 10px' }}>{x}</span>))}
              </div>
            </div>
            <div style={{ marginTop: 14, height: 220 }}>
              <CompareChart h={220} seedA={11} seedB={12} colorA={HIFI.ink} colorB={HIFI.accent} />
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 8, fontSize: 12 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 14, height: 2, background: HIFI.ink }} /> This period · <b>$342,480</b></span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: HIFI.muted }}><span style={{ width: 14, height: 2, background: HIFI.accent }} /> Previous · $316,140</span>
            </div>
          </div>

          <div className="hf-card" style={{ padding: 20 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>By venue</h3>
            <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Today · revenue</div>
            <div style={{ marginTop: 14 }}>
              {[
                ['Ocean Club', '$4,820', 0.92],
                ['The Vault', '$3,240', 0.62],
                ['Corner Café', '$2,140', 0.41],
                ['Rooftop 21', '$1,480', 0.28],
              ].map(([n, v, w]) => (
                <div key={n} style={{ padding: '10px 0', borderBottom: `1px solid ${HIFI.line}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                    <span>{n}</span>
                    <span className="hf-num">{v}</span>
                  </div>
                  <div style={{ height: 4, background: HIFI.line, borderRadius: 2, marginTop: 6, overflow: 'hidden' }}>
                    <div style={{ width: `${w*100}%`, height: '100%', background: HIFI.ink }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginTop: 14 }}>
          <div className="hf-card" style={{ padding: 20 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Today's floor</h3>
            <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginBottom: 10 }}>Ocean Club · 18 seated / 28 tables</div>
            {[
              ['Waitlist', '12 parties', HIFI.warn],
              ['Avg wait', '18 min', HIFI.ink],
              ['Turn time', '62 min', HIFI.ink],
              ['Cover rate', '92%', HIFI.good],
            ].map(([k,v,c])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:`1px solid ${HIFI.line}` }}>
                <span style={{ fontSize: 13, color: HIFI.ink2 }}>{k}</span>
                <span className="hf-num" style={{ fontSize: 15, color: c }}>{v}</span>
              </div>
            ))}
          </div>

          <div className="hf-card" style={{ padding: 20 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Menu · top 5</h3>
            <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginBottom: 10 }}>Today · by volume</div>
            {['Duck confit · 34','House burger · 28','Caesar · 24','Ribeye · 19','Oysters · 16'].map((x,i)=>{
              const [n, c] = x.split(' · ');
              return (
                <div key={n} style={{ padding: '7px 0', borderBottom: `1px solid ${HIFI.line}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                    <span>{n}</span>
                    <span className="hf-mono" style={{ color: HIFI.muted }}>{c}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="hf-card" style={{ padding: 20, background: HIFI.ink, color: HIFI.bg, position: 'relative', overflow: 'hidden' }}>
            <div className="hf-grain" />
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Ico n="sparkle" s={13} c={HIFI.accent} />
              <span className="hf-eyebrow" style={{ color: '#aaa' }}>Ross · today</span>
            </div>
            <div className="hf-display" style={{ fontSize: 22, margin: '10px 0 12px', lineHeight: 1.2 }}>
              Reorder 4 SKUs<br/>to save ~$840/wk.
            </div>
            <button className="hf-btn accent sm">Review list <Ico n="arrow" s={12} /></button>
          </div>
        </div>
      </main>
    </div>
  );
}

// Hi-fi Guests (profile-first)
function GuestsHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '260px 1fr 320px', overflow: 'hidden' }}>
      {/* List */}
      <aside style={{ borderRight: `1px solid ${HIFI.line}`, background: HIFI.paper, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '18px 16px 12px', borderBottom: `1px solid ${HIFI.line}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h2 className="hf-display" style={{ fontSize: 22, margin: 0 }}>Guests</h2>
            <span className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>12,480</span>
          </div>
          <div className="hf-input" style={{ marginTop: 10, padding: '6px 10px' }}>
            <Ico n="search" s={14} c={HIFI.muted} />
            <input placeholder="Search name, phone, email" style={{ border: 'none', outline: 'none', background: 'transparent', fontSize: 13, flex: 1, color: HIFI.ink, fontFamily: HIFI.font.body }} />
            <span className="hf-kbd">⌘F</span>
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
            {[['VIP', true],['Lapsed'],['New'],['Birthday'],['All']].map(([l,a])=>(
              <span key={l} className={`hf-chip ${a?'solid':''}`}>{l}</span>
            ))}
          </div>
        </div>
        <div style={{ overflow: 'auto', flex: 1 }}>
          {[
            ['EF','Elena Foster','VIP · 22 visits · Ocean Club', true],
            ['JR','James Rivera','Lapsed 94d · $1,840 LTV'],
            ['AP','Ava Patel','New · 1st visit Mar 28'],
            ['MK','Marco Kim','Birthday Fri · VIP'],
            ['SH','Sara Haque','VIP · 18 visits'],
            ['LB','Liam Brennan','Lapsed 60d'],
            ['RN','Rafael Nuñez','Regular · 9 visits'],
            ['IO','Imani Okonkwo','Birthday Sun · 4 visits'],
          ].map(([i,n,s,a])=>(
            <div key={n} style={{
              display: 'flex', gap: 10, padding: '12px 16px', alignItems: 'center',
              background: a ? HIFI.bg2 : 'transparent',
              borderLeft: `2px solid ${a ? HIFI.ink : 'transparent'}`,
              borderBottom: `1px solid ${HIFI.line}`,
            }}>
              <Avatar initials={i} size={34} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{n}</div>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s}</div>
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Detail */}
      <main style={{ overflow: 'auto', padding: '28px 36px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <Avatar initials="EF" size={84} tone="#e7d9be" />
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <span className="hf-chip accent"><Ico n="star" s={11} /> VIP</span>
              <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Member since Mar 2023</span>
            </div>
            <h1 className="hf-display" style={{ fontSize: 40, margin: '2px 0 2px', letterSpacing: '-0.015em' }}>Elena Foster</h1>
            <div style={{ fontSize: 13, color: HIFI.ink2, display: 'flex', gap: 14 }}>
              <span><Ico n="mail" s={12} /> elena.f@studio.com</span>
              <span><Ico n="phone" s={12} /> (415) 555-0182</span>
              <span>Ocean Club regular · Vault occasional</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="hf-btn ghost"><Ico n="mail" s={13} /> Message</button>
            <button className="hf-btn ghost"><Ico n="cal" s={13} /> Book</button>
            <button className="hf-btn"><Ico n="sparkle" s={13} /> Ask Ross</button>
          </div>
        </div>

        {/* Key metrics */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 24 }}>
          {[
            ['Lifetime', '$4,820', '87th percentile'],
            ['Visits', '22', 'every 17 days avg'],
            ['Last visit', '8d ago', 'Apr 14 · Dinner'],
            ['Avg check', '$219', '+$34 vs. house'],
          ].map(([k,v,s])=>(
            <div key={k} className="hf-card" style={{ padding: 16 }}>
              <div className="hf-eyebrow">{k}</div>
              <div className="hf-num" style={{ fontSize: 28, margin: '2px 0' }}>{v}</div>
              <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{s}</div>
            </div>
          ))}
        </div>

        {/* Visit rhythm */}
        <div className="hf-card" style={{ padding: 20, marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Visit rhythm</h3>
            <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>last 24 weeks</span>
          </div>
          <div style={{ marginTop: 12 }}>
            <BarChart h={80} seed={12} count={24} accent={22} />
          </div>
        </div>

        {/* Visit history */}
        <div className="hf-card" style={{ padding: 20, marginTop: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
            <h3 className="hf-display" style={{ fontSize: 20, margin: 0 }}>Recent visits</h3>
            <a style={{ fontSize: 12, color: HIFI.accent2, fontFamily: HIFI.font.mono }}>view all 22 →</a>
          </div>
          {[
            ['Apr 14', 'Ocean Club', 'Dinner · 2 guests', '$184', 'Loved the duck confit — server note'],
            ['Apr 02', 'Ocean Club', 'Dinner · 4 guests', '$412', 'Birthday dinner · partner James'],
            ['Mar 21', 'The Vault', 'Cocktails · 2', '$96', ''],
            ['Mar 08', 'Ocean Club', 'Dinner · 2', '$198', ''],
            ['Feb 24', 'Ocean Club', 'Brunch · 3', '$142', ''],
          ].map(([d, v, t, amt, note], i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '84px 128px 1fr 80px', gap: 14, padding: '12px 0', borderBottom: i < 4 ? `1px solid ${HIFI.line}` : 'none', alignItems: 'start' }}>
              <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>{d}</div>
              <div style={{ fontSize: 13 }}>{v}</div>
              <div>
                <div style={{ fontSize: 13 }}>{t}</div>
                {note && <div style={{ fontSize: 12, color: HIFI.accent2, marginTop: 2, fontStyle: 'italic' }}>— {note}</div>}
              </div>
              <div className="hf-num" style={{ fontSize: 15, textAlign: 'right' }}>{amt}</div>
            </div>
          ))}
        </div>
      </main>

      {/* Right rail — Ross */}
      <aside style={{ borderLeft: `1px solid ${HIFI.line}`, padding: '24px 20px', background: HIFI.bg2, overflow: 'auto' }}>
        <div className="hf-eyebrow"><Ico n="sparkle" s={11} c={HIFI.accent2} />&nbsp; Ross · about Elena</div>
        <div className="hf-card" style={{ padding: 14, marginTop: 8, borderColor: HIFI.accent + '55' }}>
          <div className="hf-display" style={{ fontSize: 18, lineHeight: 1.3 }}>
            Likely to respond to a wine tasting invite.
          </div>
          <div style={{ fontSize: 12, color: HIFI.ink2, marginTop: 6, lineHeight: 1.5 }}>
            Orders wine pairings on 80% of visits. Mentioned "natural wine" in server notes on 2 of the last 3. The Apr 28 tasting is a strong match.
          </div>
          <button className="hf-btn sm" style={{ marginTop: 10 }}>Draft invite</button>
        </div>

        <div style={{ marginTop: 20 }} className="hf-eyebrow">Preferences (learned)</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {['Window table','No cilantro','Natural wine','Birthday · Oct 14','Partner: James','Pet-friendly','Quiet seating'].map(p=>(
            <span key={p} className="hf-chip">{p}</span>
          ))}
        </div>

        <div style={{ marginTop: 20 }} className="hf-eyebrow">Allergies & notes</div>
        <div className="hf-card" style={{ padding: 12, marginTop: 8 }}>
          <div style={{ fontSize: 12.5, color: HIFI.warn, fontWeight: 500 }}>Shellfish allergy</div>
          <div style={{ fontSize: 12, color: HIFI.ink2, marginTop: 4, lineHeight: 1.5 }}>
            Flag for all visits. Last confirmed Mar 2024.
          </div>
        </div>

        <div style={{ marginTop: 20 }} className="hf-eyebrow">Relationships</div>
        <div style={{ marginTop: 8 }}>
          {[
            ['JR','James Rivera','partner · 9 joint visits'],
            ['MK','Marco Kim','colleague · 3 visits'],
          ].map(([i,n,r])=>(
            <div key={n} style={{ display: 'flex', gap: 10, padding: '8px 0', alignItems: 'center' }}>
              <Avatar initials={i} size={28} />
              <div>
                <div style={{ fontSize: 12.5 }}>{n}</div>
                <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{r}</div>
              </div>
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
}

// Hi-fi Queue (live floor)
function QueueHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '300px 1fr 280px', overflow: 'hidden' }}>
      <aside style={{ borderRight: `1px solid ${HIFI.line}`, background: HIFI.paper, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '18px 16px 12px', borderBottom: `1px solid ${HIFI.line}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h2 className="hf-display" style={{ fontSize: 22, margin: 0 }}>Waitlist</h2>
            <span className="hf-chip warn">12 waiting · 18m</span>
          </div>
          <button className="hf-btn sm" style={{ marginTop: 10, width: '100%', justifyContent: 'center' }}><Ico n="plus" s={13} /> Add party</button>
        </div>
        <div style={{ overflow: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { n: 'Rivera', size: 4, wait: '18m', quote: '20m', note: 'Anniversary', vip: true },
            { n: 'Chen', size: 2, wait: '12m', quote: '15m' },
            { n: 'Patel', size: 6, wait: '8m', quote: '10m', note: 'High chair' },
            { n: 'Kim', size: 2, wait: '6m', quote: '8m', note: 'Bar OK' },
            { n: 'Nguyen', size: 3, wait: '4m', quote: '5m' },
            { n: 'Gomez', size: 2, wait: '2m', quote: 'Seated next' },
          ].map((p, i) => (
            <div key={p.n} className="hf-card" style={{ padding: 12, background: i === 0 ? HIFI.bg2 : HIFI.paper, borderColor: i === 0 ? HIFI.ink + '33' : HIFI.line }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span className="hf-display" style={{ fontSize: 17 }}>{p.n}</span>
                  <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>· party of {p.size}</span>
                  {p.vip && <Ico n="star" s={11} c={HIFI.accent} />}
                </div>
                <span className="hf-mono" style={{ fontSize: 11, color: HIFI.warn }}>{p.wait}</span>
              </div>
              {p.note && <div style={{ fontSize: 11, color: HIFI.muted, marginTop: 4 }}>{p.note}</div>}
              <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                <button className="hf-btn sm" style={{ fontSize: 11, padding: '3px 8px' }}>Seat</button>
                <button className="hf-btn ghost sm" style={{ fontSize: 11, padding: '3px 8px' }}>Ping</button>
                <span className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginLeft: 'auto', alignSelf: 'center' }}>quoted {p.quote}</span>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main style={{ padding: 20, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div className="hf-eyebrow">Ocean Club · live</div>
            <h1 className="hf-display" style={{ fontSize: 32, margin: '2px 0 0' }}>Floor</h1>
            <div className="hf-mono" style={{ fontSize: 12, color: HIFI.muted, marginTop: 2 }}>28 tables · 18 seated · 6 open · 4 turning</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <span className="hf-chip solid">Main</span>
            <span className="hf-chip">Patio</span>
            <span className="hf-chip">Bar</span>
          </div>
        </div>

        {/* Floor plan */}
        <div style={{
          flex: 1, marginTop: 16, background: HIFI.paper,
          border: `1px solid ${HIFI.line}`, borderRadius: 8,
          position: 'relative', overflow: 'hidden',
        }}>
          <svg viewBox="0 0 100 60" preserveAspectRatio="none" style={{ position:'absolute', inset:0, width:'100%', height:'100%' }}>
            <defs><pattern id="grid" width="4" height="4" patternUnits="userSpaceOnUse">
              <path d="M 4 0 L 0 0 0 4" fill="none" stroke={HIFI.line} strokeWidth="0.1" />
            </pattern></defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            {/* Room outline */}
            <path d="M5,5 L95,5 L95,30 L85,30 L85,55 L5,55 Z" fill="none" stroke={HIFI.ink2} strokeWidth="0.4" opacity="0.4" />
            {/* Bar area */}
            <rect x="60" y="32" width="30" height="5" fill={HIFI.ink} opacity="0.08" rx="1" />
            <text x="75" y="36" fontSize="2.2" fill={HIFI.muted} textAnchor="middle" fontFamily={HIFI.font.mono}>BAR</text>
          </svg>
          {[
            { x: 14, y: 18, id: 'T1', s: 'seated', p: '2/2', t: '42min' },
            { x: 28, y: 18, id: 'T2', s: 'open' },
            { x: 44, y: 18, id: 'T3', s: 'seated', p: '4/4', t: '18min' },
            { x: 58, y: 18, id: 'T4', s: 'turning' },
            { x: 72, y: 18, id: 'T5', s: 'seated', p: '2/2', t: '8min' },
            { x: 14, y: 42, id: 'T6', s: 'seated', p: '4/4', t: '52min' },
            { x: 28, y: 42, id: 'T7', s: 'open' },
            { x: 44, y: 42, id: 'T8', s: 'seated', p: '6/6', t: '28min' },
            { x: 58, y: 42, id: 'T9', s: 'seated', p: '2/2', t: '64min', w: true },
            { x: 72, y: 64, id: 'B1', s: 'bar', p: '3/4' },
            { x: 84, y: 64, id: 'B2', s: 'open' },
          ].map(t => {
            const status = {
              seated:  { bg: HIFI.paper, border: HIFI.ink, color: HIFI.ink },
              open:    { bg: HIFI.bg2, border: HIFI.line2, color: HIFI.muted },
              turning: { bg: '#fcefe7', border: HIFI.accent, color: HIFI.accent2 },
              bar:     { bg: HIFI.paper, border: HIFI.ink, color: HIFI.ink },
            }[t.s];
            return (
              <div key={t.id} style={{
                position: 'absolute',
                left: `${t.x}%`, top: `${t.y}%`,
                transform: 'translate(-50%, -50%)',
                background: status.bg,
                border: `${t.w ? '2px' : '1px'} solid ${t.w ? HIFI.warn : status.border}`,
                borderRadius: 6, padding: '8px 12px', minWidth: 72, textAlign: 'center',
                boxShadow: t.w ? `0 0 0 4px ${HIFI.warn}15` : '0 1px 3px rgba(0,0,0,0.04)',
              }}>
                <div className="hf-display" style={{ fontSize: 16, lineHeight: 1, color: status.color }}>{t.id}</div>
                <div className="hf-mono" style={{ fontSize: 9, color: HIFI.muted, marginTop: 3 }}>
                  {t.s === 'open' ? 'OPEN' : t.s === 'turning' ? 'TURNING' : t.p}
                </div>
                {t.t && <div className="hf-mono" style={{ fontSize: 9, color: t.w ? HIFI.warn : HIFI.muted }}>{t.t}</div>}
              </div>
            );
          })}

          {/* Ross annotation */}
          <div style={{ position: 'absolute', right: 24, bottom: 24, maxWidth: 260 }}>
            <div className="hf-card" style={{ padding: 12, background: HIFI.ink, color: HIFI.bg, borderColor: HIFI.ink }}>
              <div className="hf-eyebrow" style={{ color: HIFI.accent }}><Ico n="sparkle" s={11} c={HIFI.accent} /> Ross</div>
              <div style={{ fontSize: 13, marginTop: 4, lineHeight: 1.4 }}>
                Seat <b>Chen</b> at <b>T2</b> — party of 2, quote drops from 12m to 4m.
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                <button className="hf-btn accent sm">Seat now</button>
                <button className="hf-btn ghost sm" style={{ color: HIFI.bg, borderColor: '#333' }}>Dismiss</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <aside style={{ borderLeft: `1px solid ${HIFI.line}`, background: HIFI.paper, padding: 20, overflow: 'auto' }}>
        <div className="hf-eyebrow">Service metrics</div>
        {[
          { k: 'Avg wait', v: '14m', d: '-3m vs. LW', good: true, seed: 4 },
          { k: 'Turn time', v: '62m', d: '-4m vs. LW', good: true, seed: 8 },
          { k: 'No-show rate', v: '4.2%', d: '+0.8pp', good: false, seed: 5 },
          { k: 'Cover rate', v: '92%', d: '+2pp', good: true, seed: 6 },
        ].map(m=>(
          <div key={m.k} className="hf-card" style={{ padding: 14, marginTop: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: 12, color: HIFI.muted }}>{m.k}</span>
              <span className="hf-mono" style={{ fontSize: 10, color: m.good ? HIFI.good : HIFI.warn }}>{m.d}</span>
            </div>
            <div className="hf-num" style={{ fontSize: 26 }}>{m.v}</div>
            <Sparkline seed={m.seed} h={24} color={m.good ? HIFI.good : HIFI.warn} />
          </div>
        ))}

        <div className="hf-eyebrow" style={{ marginTop: 22 }}>Tonight · 6:00–11:00</div>
        <div className="hf-card" style={{ padding: 12, marginTop: 8 }}>
          <div style={{ fontSize: 12.5 }}>38 bookings · 142 covers expected</div>
          <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 4 }}>Peak: 8:15 PM · 92% utilization</div>
          <BarChart h={40} seed={17} count={10} color={HIFI.ink} />
        </div>
      </aside>
    </div>
  );
}

// Hi-fi Analytics (narrative brief)
function AnalyticsHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', overflow: 'auto' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '48px 56px' }}>
        {/* Masthead */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: `1px solid ${HIFI.ink}`, paddingBottom: 14 }}>
          <Logo size={22} />
          <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, letterSpacing: '0.1em' }}>WEEKLY BRIEF · WEEK 17 · APR 14–20</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="hf-btn ghost sm">Print</button>
            <button className="hf-btn sm">Share with team</button>
          </div>
        </div>

        <div style={{ marginTop: 40 }}>
          <div className="hf-eyebrow">Ross · executive summary</div>
          <h1 className="hf-display" style={{ fontSize: 68, margin: '12px 0 8px', lineHeight: 0.98, letterSpacing: '-0.025em', maxWidth: 900 }}>
            A strong week, with <span style={{ fontStyle: 'italic', color: HIFI.warn }}>one&nbsp;warning.</span>
          </h1>
          <div style={{ fontSize: 17, color: HIFI.ink2, lineHeight: 1.55, maxWidth: 720, marginTop: 10 }}>
            Revenue climbed <b>8.2%</b> across the group — Ocean Club and The Vault carried the week. Food cost slipped <b>3.4&nbsp;points</b> at Ocean Club; the other three venues held steady. Here's what Ross noticed, and what we suggest next.
          </div>
        </div>

        {/* Hero data */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24, marginTop: 40 }}>
          <div className="hf-card" style={{ padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
              <div>
                <div className="hf-eyebrow">Revenue · week over week</div>
                <div className="hf-num" style={{ fontSize: 44, marginTop: 4 }}>$86,420</div>
                <div className="hf-mono" style={{ fontSize: 12, color: HIFI.good }}>↑ 8.2% · +$6,560 vs. W16</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['Ocean','Vault','Café','Rooftop'].map((n,i)=>(
                  <span key={n} className="hf-chip" style={{ color: HIFI.ink }}>
                    <span className="hf-dot" style={{ background: [HIFI.ink, HIFI.accent, HIFI.good, HIFI.gold][i] }} /> {n}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ marginTop: 16 }}>
              <LineChart h={180} seed={13} stroke={HIFI.ink} fill={HIFI.accent} />
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              ['Covers', '2,184', '+4.1%', true],
              ['Avg check', '$39.57', '+$1.80', true],
              ['Food cost', '29.8%', '+1.1pp', false],
              ['NPS', '74', '+3', true],
            ].map(([k,v,d,g])=>(
              <div key={k} className="hf-card" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ flex: 1 }}>
                  <div className="hf-eyebrow">{k}</div>
                  <div className="hf-num" style={{ fontSize: 24 }}>{v}</div>
                </div>
                <div className="hf-mono" style={{ fontSize: 11, color: g ? HIFI.good : HIFI.warn }}>{g ? '↑' : '↓'} {d}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Three stories */}
        <div style={{ marginTop: 56 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 16 }}>
            <h2 className="hf-display" style={{ fontSize: 34, margin: 0, letterSpacing: '-0.02em' }}>What Ross noticed.</h2>
            <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>3 STORIES · 12 SUB-INSIGHTS</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginTop: 24 }}>
            {[
              { n: '01', t: 'Patio drove $6.2k on Saturday.', d: 'Weather (73°, sunny) plus the spring promo compounded. If you extend, Ross projects +$4.8k next Saturday.', m: ['+$6,240', 'Saturday'], c: HIFI.good },
              { n: '02', t: 'Wine attach rose 14% group-wide.', d: 'The new sommelier pairings are landing. Pairing attach at Ocean Club hit 38%, up from 24%.', m: ['+14%', 'Wine attach'], c: HIFI.ink },
              { n: '03', t: 'Ocean Club protein cost drifted.', d: 'Ribeye and duck cost rose 4pp for 5 days straight. Supplier raised Apr 18 — menu hasn\'t adjusted.', m: ['+3.4pp', 'COGS'], c: HIFI.warn },
            ].map(s=>(
              <div key={s.n} style={{ paddingTop: 14, borderTop: `1px solid ${HIFI.ink}` }}>
                <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, letterSpacing: '0.14em' }}>{s.n}</div>
                <h3 className="hf-display" style={{ fontSize: 24, margin: '10px 0 8px', lineHeight: 1.2 }}>{s.t}</h3>
                <div style={{ fontSize: 13.5, color: HIFI.ink2, lineHeight: 1.55 }}>{s.d}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 16 }}>
                  <span className="hf-num" style={{ fontSize: 28, color: s.c }}>{s.m[0]}</span>
                  <span className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{s.m[1]}</span>
                </div>
                <a style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginTop: 12, fontSize: 12, color: HIFI.accent2, fontFamily: HIFI.font.mono }}>Open brief <Ico n="arrow" s={12} c={HIFI.accent2} /></a>
              </div>
            ))}
          </div>
        </div>

        {/* Forecast */}
        <div style={{ marginTop: 56 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
            <h2 className="hf-display" style={{ fontSize: 34, margin: 0 }}>Forecast · next 7 days.</h2>
            <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>80% CONFIDENCE · UPDATED 9:10 AM</span>
          </div>
          <div className="hf-card" style={{ padding: 24, marginTop: 16 }}>
            <LineChart h={160} seed={16} stroke={HIFI.ink} />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderTop: `1px solid ${HIFI.line}`, marginTop: 14, paddingTop: 12 }}>
              {[['Wed','$11.2k'],['Thu','$12.4k'],['Fri','$14.1k'],['Sat','$16.2k'],['Sun','$13.6k'],['Mon','$9.8k'],['Tue','$11.0k']].map(([d,v])=>(
                <div key={d} style={{ textAlign: 'center' }}>
                  <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>{d}</div>
                  <div className="hf-num" style={{ fontSize: 16, marginTop: 2 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="hf-mono" style={{ fontSize: 11, color: HIFI.muted, marginTop: 10, textAlign: 'center' }}>
            Week projected: $88,300 · +2.2% vs. this week
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: 64, paddingTop: 20, borderTop: `1px solid ${HIFI.line}`, display: 'flex', justifyContent: 'space-between' }}>
          <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Sparks Hospitality · Ross v4.2 · Generated Tue 9:14 AM</span>
          <span className="hf-mono" style={{ fontSize: 11, color: HIFI.muted }}>Next brief: Mon Apr 28</span>
        </div>
      </div>
    </div>
  );
}

// Mobile Ross
function MobileHiFi() {
  return (
    <div className="hf-body" style={{ width: '100%', height: '100%', padding: 0, background: HIFI.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Status bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 20px 4px', fontSize: 12, fontWeight: 600 }}>
        <span>9:14</span>
        <span className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>•••• 5G ▮▮▮</span>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Logo size={18} />
          <Avatar initials="MA" size={30} />
        </div>

        <div style={{ marginTop: 20 }}>
          <div className="hf-eyebrow">Tuesday · Apr 22</div>
          <h1 className="hf-display" style={{ fontSize: 32, margin: '4px 0 4px', lineHeight: 1.05, letterSpacing: '-0.02em' }}>
            Morning,<br/>
            <span style={{ fontStyle: 'italic', color: HIFI.muted }}>Maya.</span>
          </h1>
          <div style={{ fontSize: 13, color: HIFI.ink2 }}>3 things worth your time.</div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
          <div className="hf-card" style={{ padding: 14, borderColor: HIFI.warn + '55' }}>
            <span className="hf-chip warn"><span className="hf-dot" style={{ background: HIFI.warn }} /> Attention</span>
            <div className="hf-display" style={{ fontSize: 18, marginTop: 8, lineHeight: 1.2 }}>Ocean Club food cost at 34.1%</div>
            <LineChart h={34} seed={9} stroke={HIFI.warn} fill={HIFI.warn} />
            <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted }}>Target 28% · 3 days running</div>
          </div>

          <div className="hf-card" style={{ padding: 14 }}>
            <span className="hf-chip"><Ico n="users" s={11} /> Guests</span>
            <div className="hf-display" style={{ fontSize: 18, marginTop: 8, lineHeight: 1.2 }}>42 VIPs lapsed — draft ready</div>
            <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 6 }}>$2,180 avg LTV · 28% projected return</div>
          </div>

          <div className="hf-card" style={{ padding: 14 }}>
            <span className="hf-chip good"><Ico n="check" s={11} /> Win</span>
            <div className="hf-display" style={{ fontSize: 18, marginTop: 8, lineHeight: 1.2 }}>Weekend forecast +18%</div>
            <div className="hf-mono" style={{ fontSize: 10, color: HIFI.muted, marginTop: 6 }}>Patio promo driving it</div>
          </div>
        </div>
      </div>

      <div style={{ padding: '10px 14px', background: HIFI.ink, color: HIFI.bg, margin: '0 16px 8px', borderRadius: 26, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Ico n="sparkle" s={16} c={HIFI.accent} />
        <span style={{ fontSize: 13, flex: 1, color: '#aaa' }}>Ask Ross anything…</span>
        <Ico n="bolt" s={14} c={HIFI.accent} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '10px 0 16px', borderTop: `1px solid ${HIFI.line}`, background: HIFI.paper }}>
        {[['bolt',true],['chart'],['users'],['clock'],['user']].map(([n,a],i)=>(
          <div key={i} style={{ padding: 8, color: a ? HIFI.ink : HIFI.muted }}><Ico n={n} s={20} /></div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { RossHiFi, DashHiFi, GuestsHiFi, QueueHiFi, AnalyticsHiFi, MobileHiFi });
