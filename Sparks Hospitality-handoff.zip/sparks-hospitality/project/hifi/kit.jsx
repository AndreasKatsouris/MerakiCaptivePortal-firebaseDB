// Hi-fi design tokens + components for Sparks
// "Editorial Hospitality OS" — warm, premium, operator-grade

const HIFI = {
  // Colors (oklch harmonized)
  bg:       '#f7f4ec',   // bone
  bg2:      '#efeadd',   // sand
  paper:    '#fbf9f3',   // cream card
  ink:      '#1a1812',   // deep ink
  ink2:     '#3a362d',
  muted:    '#7a7565',
  line:     '#e6dfcd',
  line2:    '#d4ccb6',
  hair:     '#0a0804',
  accent:   '#c89a3a',   // warm amber (oklch 0.70 0.12 80)
  accent2:  '#a8772a',
  good:     '#5c7a4a',
  warn:     '#b0553a',   // terracotta
  crit:     '#8a2e1f',
  gold:     '#b4903b',

  font: {
    display: "'Instrument Serif', 'Cormorant Garamond', Georgia, serif",
    body:    "'Geist', 'Söhne', 'Inter', system-ui, sans-serif",
    mono:    "'JetBrains Mono', ui-monospace, monospace",
  },
};

const css = `
  :root {
    --bg: ${HIFI.bg};
    --paper: ${HIFI.paper};
    --ink: ${HIFI.ink};
    --muted: ${HIFI.muted};
    --line: ${HIFI.line};
    --accent: ${HIFI.accent};
  }
  * { box-sizing: border-box; }
  ::-webkit-scrollbar { width: 10px; height: 10px; }
  ::-webkit-scrollbar-thumb { background: ${HIFI.line2}; border-radius: 10px; }
  ::-webkit-scrollbar-track { background: transparent; }
  .hf-body {
    font-family: ${HIFI.font.body};
    color: ${HIFI.ink};
    background: ${HIFI.bg};
    font-feature-settings: "ss01","cv11";
    -webkit-font-smoothing: antialiased;
  }
  .hf-display { font-family: ${HIFI.font.display}; font-weight: 400; letter-spacing: -0.01em; }
  .hf-mono { font-family: ${HIFI.font.mono}; font-feature-settings: "tnum","zero"; }
  .hf-eyebrow { font-family: ${HIFI.font.mono}; font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: ${HIFI.muted}; }
  .hf-grain {
    position: absolute; inset: 0; pointer-events: none; opacity: 0.06; mix-blend-mode: multiply;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  }
  .hf-card {
    background: ${HIFI.paper};
    border: 1px solid ${HIFI.line};
    border-radius: 6px;
  }
  .hf-hair { border-top: 1px solid ${HIFI.line}; }
  .hf-btn {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 8px 14px; font-size: 13px; font-weight: 500;
    border-radius: 4px; cursor: pointer; border: 1px solid ${HIFI.ink};
    background: ${HIFI.ink}; color: ${HIFI.bg};
    font-family: ${HIFI.font.body};
    letter-spacing: 0.01em;
    transition: transform .1s ease, background .2s;
  }
  .hf-btn.ghost { background: transparent; color: ${HIFI.ink}; border-color: ${HIFI.line2}; }
  .hf-btn.outline { background: ${HIFI.paper}; color: ${HIFI.ink}; }
  .hf-btn.sm { padding: 5px 10px; font-size: 12px; }
  .hf-btn.accent { background: ${HIFI.accent}; border-color: ${HIFI.accent}; color: ${HIFI.ink}; }
  .hf-chip {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 3px 10px; font-size: 11px; letter-spacing: 0.02em;
    border-radius: 999px; border: 1px solid ${HIFI.line2};
    background: ${HIFI.paper}; color: ${HIFI.ink2};
    font-family: ${HIFI.font.body};
  }
  .hf-chip.solid { background: ${HIFI.ink}; color: ${HIFI.bg}; border-color: ${HIFI.ink}; }
  .hf-chip.accent { background: transparent; color: ${HIFI.accent2}; border-color: ${HIFI.accent}; }
  .hf-chip.warn { color: ${HIFI.warn}; border-color: ${HIFI.warn}33; background: ${HIFI.warn}0d; }
  .hf-chip.good { color: ${HIFI.good}; border-color: ${HIFI.good}33; background: ${HIFI.good}0d; }
  .hf-input {
    display: flex; align-items: center; gap: 8px;
    padding: 8px 12px; border: 1px solid ${HIFI.line2};
    border-radius: 4px; background: ${HIFI.paper};
    font-family: ${HIFI.font.body}; font-size: 13px; color: ${HIFI.ink};
  }
  .hf-dot { width: 6px; height: 6px; border-radius: 50%; display: inline-block; }
  .hf-nav-item {
    display: flex; align-items: center; gap: 10px; padding: 7px 10px;
    font-size: 13px; color: ${HIFI.ink2}; border-radius: 4px; cursor: default;
    letter-spacing: 0.005em;
  }
  .hf-nav-item.active { background: ${HIFI.ink}; color: ${HIFI.bg}; }
  .hf-kbd {
    font-family: ${HIFI.font.mono}; font-size: 10px;
    padding: 2px 5px; border: 1px solid ${HIFI.line2}; border-radius: 3px;
    background: ${HIFI.paper}; color: ${HIFI.muted};
  }
  .hf-num { font-family: ${HIFI.font.display}; font-feature-settings: "tnum","lnum"; letter-spacing: -0.02em; }
`;

function HiFiStyle() { return <style dangerouslySetInnerHTML={{ __html: css }} />; }

// Icon system — clean 1.5px stroke linework
function Ico({ n, s = 16, c = 'currentColor', sw = 1.5 }) {
  const p = { width: s, height: s, viewBox: '0 0 24 24', fill: 'none', stroke: c, strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const d = {
    search: <><circle cx="11" cy="11" r="6" /><path d="m16 16 4 4" /></>,
    bell:   <><path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4l2-2Z" /><path d="M10 20a2 2 0 0 0 4 0" /></>,
    user:   <><circle cx="12" cy="8" r="4" /><path d="M4 21c1-4 4-6 8-6s7 2 8 6" /></>,
    users:  <><circle cx="9" cy="8" r="3.5" /><circle cx="17" cy="9" r="2.5" /><path d="M3 20c0-3 3-5 6-5s6 2 6 5" /><path d="M15 20c0-2 2-4 5-3.5" /></>,
    chart:  <><path d="M4 20h16" /><path d="M7 16V10" /><path d="M12 16V6" /><path d="M17 16V13" /></>,
    line:   <><path d="M4 18V6" /><path d="M4 18h16" /><path d="M5 15l5-5 4 3 5-7" /></>,
    bolt:   <path d="M13 3 4 14h7l-1 7 9-11h-7l1-7Z" />,
    clock:  <><circle cx="12" cy="12" r="8" /><path d="M12 8v4l3 2" /></>,
    cal:    <><rect x="4" y="5" width="16" height="16" rx="2" /><path d="M4 10h16" /><path d="M9 3v4" /><path d="M15 3v4" /></>,
    cart:   <><path d="M3 4h2l2 12h11l2-8H6" /><circle cx="9" cy="20" r="1.3" /><circle cx="17" cy="20" r="1.3" /></>,
    route:  <><circle cx="6" cy="6" r="2" /><circle cx="18" cy="18" r="2" /><path d="M8 6h6a4 4 0 0 1 4 4v0a4 4 0 0 1-4 4h-4a4 4 0 0 0-4 4" /></>,
    gear:   <><circle cx="12" cy="12" r="3" /><path d="M19.4 15A1.7 1.7 0 0 0 20 14l1-.8a9 9 0 0 0 0-2.4L20 10a1.7 1.7 0 0 0-.6-1l.3-1.2a9 9 0 0 0-2-2l-1.2.3a1.7 1.7 0 0 0-1-.6L14 4.4a9 9 0 0 0-2.4 0L10.8 5.4a1.7 1.7 0 0 0-1 .6L8.6 5.7a9 9 0 0 0-2 2l.3 1.2a1.7 1.7 0 0 0-.6 1L5.3 10.8a9 9 0 0 0 0 2.4L6.3 14a1.7 1.7 0 0 0 .6 1l-.3 1.2a9 9 0 0 0 2 2l1.2-.3a1.7 1.7 0 0 0 1 .6l.8 1.1a9 9 0 0 0 2.4 0l.8-1.1a1.7 1.7 0 0 0 1-.6l1.2.3a9 9 0 0 0 2-2l-.3-1.2Z" /></>,
    send:   <><path d="m4 12 16-8-7 16-2-7Z" /><path d="m4 12 9 1" /></>,
    plus:   <><path d="M12 5v14" /><path d="M5 12h14" /></>,
    arrow:  <><path d="M5 12h14" /><path d="m14 6 6 6-6 6" /></>,
    up:     <><path d="M12 19V5" /><path d="m6 11 6-6 6 6" /></>,
    down:   <><path d="M12 5v14" /><path d="m6 13 6 6 6-6" /></>,
    check:  <path d="m5 12 5 5L20 7" />,
    x:      <><path d="m6 6 12 12" /><path d="m6 18 12-12" /></>,
    star:   <path d="m12 3 2.8 6.2 6.7.6-5 4.6 1.5 6.6L12 17.8 6 21l1.5-6.6-5-4.6 6.7-.6Z" />,
    sparkle:<><path d="M12 3v4" /><path d="M12 17v4" /><path d="M3 12h4" /><path d="M17 12h4" /><path d="m6 6 2 2" /><path d="m16 16 2 2" /><path d="m6 18 2-2" /><path d="m16 8 2-2" /></>,
    fire:   <path d="M12 3c1 3 5 5 4 10a5 5 0 0 1-10 0c0-3 2-4 3-7 .5 1.5 1 2 2 2.5Z" />,
    menu:   <><path d="M3 6h18" /><path d="M3 12h18" /><path d="M3 18h18" /></>,
    filter: <><path d="M4 5h16" /><path d="M7 12h10" /><path d="M10 19h4" /></>,
    cmd:    <><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6Z" /></>,
    wine:   <><path d="M8 4h8l-1 6a3 3 0 0 1-6 0L8 4Z" /><path d="M12 13v7" /><path d="M9 20h6" /></>,
    coffee: <><path d="M5 10h12v4a5 5 0 0 1-10 0v-4Z" /><path d="M17 12h2a2 2 0 0 1 0 4h-2" /><path d="M8 4v2" /><path d="M12 4v2" /></>,
    bed:    <><path d="M3 18v-8h13a4 4 0 0 1 4 4v4" /><path d="M3 14h17" /><circle cx="7" cy="12" r="1.5" /></>,
    phone:  <><path d="M5 4h4l2 5-2 1a12 12 0 0 0 5 5l1-2 5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z" /></>,
    mail:   <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 7 9-7" /></>,
    dot:    <circle cx="12" cy="12" r="3" />,
    ellipsis: <><circle cx="5" cy="12" r="1.3" /><circle cx="12" cy="12" r="1.3" /><circle cx="19" cy="12" r="1.3" /></>,
    leaf:   <><path d="M20 4c-2 10-8 14-14 14 0-6 4-12 14-14Z" /><path d="M5 19l8-8" /></>,
  };
  return <svg {...p}>{d[n] || d.dot}</svg>;
}

// Line chart — smooth, anti-aliased
function LineChart({ h = 80, seed = 1, stroke = HIFI.ink, fill, dashed = false, points = 28, min, max, showDots = false, className }) {
  let s = seed * 9301 + 49297;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const pts = [];
  let y = 0.5;
  for (let i = 0; i < points; i++) {
    y += (rnd() - 0.48) * 0.18;
    y = Math.max(0.08, Math.min(0.92, y));
    pts.push([i / (points - 1) * 100, y * 100]);
  }
  // smooth catmull-rom to bezier
  const path = pts.reduce((acc, p, i, a) => {
    if (i === 0) return `M ${p[0]} ${p[1]}`;
    const prev = a[i-1], next = a[i+1] || p, prev2 = a[i-2] || prev;
    const c1x = prev[0] + (p[0] - prev2[0]) / 6;
    const c1y = prev[1] + (p[1] - prev2[1]) / 6;
    const c2x = p[0] - (next[0] - prev[0]) / 6;
    const c2y = p[1] - (next[1] - prev[1]) / 6;
    return acc + ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p[0]} ${p[1]}`;
  }, '');
  const area = fill ? `${path} L 100 100 L 0 100 Z` : null;
  const gid = `g${seed}`;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height: h, display: 'block' }} className={className}>
      {fill && (
        <defs>
          <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor={fill} stopOpacity="0.35" />
            <stop offset="1" stopColor={fill} stopOpacity="0" />
          </linearGradient>
        </defs>
      )}
      {area && <path d={area} fill={`url(#${gid})`} />}
      <path d={path} fill="none" stroke={stroke} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={dashed ? '3 3' : undefined} vectorEffect="non-scaling-stroke" />
      {showDots && pts.filter((_, i) => i % 4 === 0).map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="0.9" fill={stroke} vectorEffect="non-scaling-stroke" />
      ))}
    </svg>
  );
}

// Area comparison — two lines
function CompareChart({ h = 120, seedA = 1, seedB = 2, colorA = HIFI.ink, colorB = HIFI.accent }) {
  return (
    <div style={{ position: 'relative', width: '100%', height: h }}>
      <div style={{ position: 'absolute', inset: 0 }}>
        <LineChart h={h} seed={seedB} stroke={colorB} fill={colorB} />
      </div>
      <div style={{ position: 'absolute', inset: 0 }}>
        <LineChart h={h} seed={seedA} stroke={colorA} />
      </div>
    </div>
  );
}

function BarChart({ h = 80, seed = 2, count = 12, accent = -1, color = HIFI.ink, accentColor = HIFI.accent }) {
  let s = seed * 9301 + 49297;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const bars = Array.from({ length: count }, () => 0.2 + rnd() * 0.75);
  const gap = 2.5, bw = (100 - gap * (count - 1)) / count;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height: h, display: 'block' }}>
      {bars.map((v, i) => (
        <rect key={i} x={i * (bw + gap)} y={100 - v * 100} width={bw} height={v * 100} rx="0.6"
          fill={i === accent ? accentColor : color} opacity={i === accent ? 1 : 0.88} />
      ))}
    </svg>
  );
}

function Donut({ size = 80, pct = 0.62, color = HIFI.ink, track = HIFI.line, label, sub }) {
  const r = 40, c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size, display: 'inline-block' }}>
      <svg width={size} height={size} viewBox="0 0 100 100">
        <circle cx="50" cy="50" r={r} fill="none" stroke={track} strokeWidth="8" />
        <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="8"
          strokeDasharray={`${(c * pct).toFixed(1)} ${c.toFixed(1)}`} strokeLinecap="round"
          transform="rotate(-90 50 50)" />
      </svg>
      {label && <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <div className="hf-num" style={{ fontSize: size * 0.26 }}>{label}</div>
        {sub && <div className="hf-mono" style={{ fontSize: 9, color: HIFI.muted }}>{sub}</div>}
      </div>}
    </div>
  );
}

function Sparkline({ seed = 3, color = HIFI.ink, h = 24 }) {
  return <LineChart h={h} seed={seed} stroke={color} points={16} />;
}

function Avatar({ initials = 'A', size = 32, tone }) {
  const tones = ['#e7d9be','#d9e3cd','#e5cfc2','#cfd4e3','#e3cfd7','#d4dcca'];
  const bg = tone || tones[(initials.charCodeAt(0) || 0) % tones.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: bg, color: HIFI.ink, display: 'inline-flex',
      alignItems: 'center', justifyContent: 'center',
      fontFamily: HIFI.font.display, fontSize: size * 0.42,
      border: `1px solid ${HIFI.line}`, flexShrink: 0,
    }}>{initials}</div>
  );
}

// Logo — simple, editorial
function Logo({ size = 20, color = HIFI.ink }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
        <path d="M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z" fill={color} />
      </svg>
      <span className="hf-display" style={{ fontSize: size * 0.95, letterSpacing: '-0.01em' }}>Sparks</span>
    </div>
  );
}

Object.assign(window, {
  HIFI, HiFiStyle, Ico, LineChart, CompareChart, BarChart, Donut, Sparkline, Avatar, Logo,
});
