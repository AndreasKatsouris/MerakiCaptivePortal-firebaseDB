// ROSS home — two variants
// A: Concierge card-stack (editorial, warm, guided)
// B: Command console (dense, keyboard-first, operator)

function RossA() {
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', display: 'flex', flexDirection: 'column' }}>
      {/* top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 22px', borderBottom: '1px dashed #1a1a1a55' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 26, height: 26, background: '#111', color: '#fff', display: 'grid', placeItems: 'center', ...rough('#111', 1.4) }}>
            <H size={13} font="hand" style={{ color: '#fff' }}>R</H>
          </div>
          <H size={18} font="hand">Sparks · Ross</H>
          <H size={11} font="mono" style={{ color: '#666', marginLeft: 6 }}>concierge</H>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <H size={12} font="mono" style={{ color: '#666' }}>Tue · Apr 22 · 9:14 AM</H>
          <WAvatar initials="MA" />
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, padding: 28 }}>
        {/* LEFT — conversation */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20, overflow: 'hidden' }}>
          <div>
            <H size={12} font="mono" style={{ color: '#888', marginBottom: 6 }}>Good morning, Maya.</H>
            <H size={38} font="hand" style={{ lineHeight: 1.05 }}>
              Three things I think<br />you should look at today.
            </H>
            <H size={13} font="ui" style={{ color: '#555', marginTop: 8, maxWidth: 520 }}>
              Ross watched overnight activity across all 4 venues. Here's what changed while you slept.
            </H>
          </div>

          {/* card stack — each card is a "thread" */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <WBox tone="accent" pad={16} style={{ position: 'relative' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                <WChip tone="ink"><WIcon name="fire" size={11} stroke="#fff" />&nbsp;urgent</WChip>
                <div style={{ flex: 1 }}>
                  <H size={17} font="hand">Food cost spiked at Ocean Club.</H>
                  <H size={12} font="ui" style={{ color: '#444', marginTop: 4 }}>
                    COGS ran at 34.1% vs. 28% target for 3 days straight. Protein line is the culprit.
                  </H>
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <WBtn tone="ink" size="sm">Open food-cost brief →</WBtn>
                    <WBtn size="sm">Ask Ross why</WBtn>
                    <WBtn tone="ghost" size="sm">Snooze 24h</WBtn>
                  </div>
                </div>
                <div style={{ width: 120 }}>
                  <WLineChart h={44} seed={9} fill="#f4b400" />
                  <H size={10} font="mono" style={{ textAlign: 'right', color: '#888' }}>7-day COGS</H>
                </div>
              </div>
            </WBox>

            <WBox pad={16}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                <WChip><WIcon name="users" size={11} />&nbsp;guest</WChip>
                <div style={{ flex: 1 }}>
                  <H size={17} font="hand">42 VIP guests haven't returned in 90+ days.</H>
                  <H size={12} font="ui" style={{ color: '#444', marginTop: 4 }}>
                    Avg. lifetime spend $2,180. Ross drafted a win-back campaign — needs your approval.
                  </H>
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <WBtn tone="ink" size="sm">Review draft</WBtn>
                    <WBtn size="sm">See the 42 guests</WBtn>
                  </div>
                </div>
                <div style={{ width: 90, textAlign: 'center' }}>
                  <WDonut size={64} pct={0.28} />
                  <H size={10} font="mono" style={{ color: '#888', marginTop: 2 }}>28% return</H>
                </div>
              </div>
            </WBox>

            <WBox pad={16}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                <WChip tone="good"><WIcon name="check" size={11} />&nbsp;win</WChip>
                <div style={{ flex: 1 }}>
                  <H size={17} font="hand">Weekend forecast beat last week by 18%.</H>
                  <H size={12} font="ui" style={{ color: '#444', marginTop: 4 }}>
                    Likely driver: the patio promotion. Ross suggests extending 2 weeks.
                  </H>
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <WBtn tone="ink" size="sm">Extend promotion</WBtn>
                    <WBtn size="sm">See breakdown</WBtn>
                  </div>
                </div>
                <div style={{ width: 120 }}>
                  <WBarChart h={44} seed={3} accent={6} />
                </div>
              </div>
            </WBox>
          </div>

          <div style={{ marginTop: 'auto', display: 'flex', gap: 10, alignItems: 'center' }}>
            <H size={12} font="mono" style={{ color: '#888' }}>or jump straight to —</H>
            {['Guests', 'Queue', 'Analytics', 'Food cost', 'Campaigns'].map(x => (
              <WChip key={x}>{x}</WChip>
            ))}
          </div>
        </div>

        {/* RIGHT — ask Ross */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <WBox tone="ink" pad={14}>
            <H size={11} font="mono" style={{ color: '#bbb', marginBottom: 6 }}>ask ross</H>
            <H size={15} font="hand" style={{ color: '#fff' }}>"How did my Saturday brunch compare to last month?"</H>
            <div style={{ marginTop: 10, borderTop: '1px dashed #444', paddingTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <WChip tone="accent">↑ 22% covers</WChip>
              <WChip tone="accent">avg check $48</WChip>
              <WChip tone="accent">waitlist peaked 43m</WChip>
            </div>
          </WBox>

          <WBox pad={12}>
            <H size={11} font="mono" style={{ color: '#888', marginBottom: 8 }}>live — all venues</H>
            {[
              ['Ocean Club', 'open', 64, 'good'],
              ['The Vault', 'open', 38, 'good'],
              ['Corner Café', 'setup', 0, 'warn'],
              ['Rooftop 21', 'closed', 0, 'plain'],
            ].map(([n, s, cov, tone]) => (
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: '1px dashed #1a1a1a22' }}>
                <WIcon name="dot" stroke={tone === 'good' ? '#2f6b3a' : tone === 'warn' ? '#c0392b' : '#888'} />
                <H size={13} font="ui" style={{ flex: 1 }}>{n}</H>
                <H size={11} font="mono" style={{ color: '#888' }}>{s}</H>
                <H size={12} font="hand">{cov || '—'}</H>
              </div>
            ))}
          </WBox>

          <WBox pad={12}>
            <H size={11} font="mono" style={{ color: '#888', marginBottom: 8 }}>ross suggests</H>
            {[
              '87 guests celebrate birthdays this week',
              'Low stock: olive oil (2 days)',
              'Staff schedule has a Sat gap 6–8pm',
            ].map(s => (
              <div key={s} style={{ display: 'flex', gap: 6, alignItems: 'center', padding: '4px 0' }}>
                <WIcon name="spark" />
                <H size={12} font="ui">{s}</H>
              </div>
            ))}
          </WBox>
        </div>
      </div>
    </div>
  );
}

function RossB() {
  // Command console — terminal-like, dense, operator-first
  return (
    <div style={{ width: '100%', height: '100%', background: '#0f0f10', color: '#f1ede2', display: 'flex', flexDirection: 'column', fontFamily: WF_FONTS.ui }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 16px', borderBottom: '1px dashed #f1ede233' }}>
        <div style={{ width: 10, height: 10, background: '#f4b400', borderRadius: 2 }} />
        <H size={12} font="mono" style={{ color: '#f1ede2' }}>ROSS · restaurant operations support system</H>
        <H size={11} font="mono" style={{ color: '#888', marginLeft: 'auto' }}>v4.2 · uptime 11d 4h</H>
      </div>

      {/* big command bar */}
      <div style={{ padding: '28px 28px 8px' }}>
        <H size={12} font="mono" style={{ color: '#888' }}>~ sparks · 4 venues · tue 09:14</H>
        <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 12, background: '#1a1a1c', padding: '16px 18px', ...rough('#f1ede244', 1.2) }}>
          <H size={22} font="mono" style={{ color: '#f4b400' }}>›</H>
          <H size={22} font="ui" style={{ color: '#fff', flex: 1 }}>
            Ask Ross anything about your restaurants<span style={{ opacity: 0.5 }}>_</span>
          </H>
          <WChip tone="ink" style={{ borderColor: '#f1ede244', color: '#f1ede2' }}>⌘K</WChip>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
          {['why did covers drop sat?', 'rank stores by margin', 'draft staff msg', 'reorder low stock', '↑ 3 more'].map(x => (
            <WChip key={x} style={{ background: '#1a1a1c', color: '#f1ede2', borderColor: '#f1ede244' }}>{x}</WChip>
          ))}
        </div>
      </div>

      {/* briefing grid */}
      <div style={{ flex: 1, padding: '18px 28px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, overflow: 'hidden' }}>
        {[
          { k: 'revenue · today', v: '$12,480', d: '↑ 8.2%', chart: 1 },
          { k: 'covers · today',  v: '316',      d: '↑ 12',  chart: 2 },
          { k: 'avg check',        v: '$39.50',  d: '↓ $1.20', chart: 3 },
          { k: 'food cost (7d)',  v: '31.4%',   d: '↑ 3.4pp', chart: 4, warn: true },
        ].map(m => (
          <div key={m.k} style={{ padding: 14, background: '#1a1a1c', ...rough('#f1ede222', 1) }}>
            <H size={10} font="mono" style={{ color: '#888' }}>{m.k}</H>
            <H size={26} font="hand" style={{ color: m.warn ? '#f4b400' : '#fff', marginTop: 2 }}>{m.v}</H>
            <H size={11} font="mono" style={{ color: m.warn ? '#f4b400' : '#7fbf8d' }}>{m.d}</H>
            <div style={{ marginTop: 6 }}>
              <WLineChart h={28} seed={m.chart} stroke={m.warn ? '#f4b400' : '#f1ede2'} />
            </div>
          </div>
        ))}

        {/* feed */}
        <div style={{ gridColumn: 'span 3', padding: 14, background: '#1a1a1c', ...rough('#f1ede222', 1), display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <H size={11} font="mono" style={{ color: '#888' }}>ross · last 12h</H>
            <H size={11} font="mono" style={{ color: '#888' }}>24 events · filter ⌄</H>
          </div>
          <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              ['09:02', 'FLAG', 'Ocean Club COGS exceeded threshold (34.1%)', '#f4b400'],
              ['08:41', 'INFO', 'Forecast updated — weekend revenue +18% vs. LW', '#7fbf8d'],
              ['08:30', 'ACT',  'Draft win-back campaign for 42 lapsed VIPs — ready', '#f1ede2'],
              ['07:55', 'FLAG', 'Low stock: olive oil, 5L drums at 2 units', '#f4b400'],
              ['07:10', 'INFO', 'Queue wait p95 dropped 3m across all venues',    '#7fbf8d'],
              ['06:44', 'ACT',  'Schedule gap detected: Sat 18:00–20:00, Ocean Club', '#f1ede2'],
            ].map(([t, k, m, c]) => (
              <div key={t+m} style={{ display: 'grid', gridTemplateColumns: '52px 54px 1fr auto', gap: 10, alignItems: 'center', fontFamily: WF_FONTS.mono, fontSize: 12, padding: '4px 0', borderBottom: '1px dashed #f1ede215' }}>
                <span style={{ color: '#666' }}>{t}</span>
                <span style={{ color: c, fontWeight: 600 }}>{k}</span>
                <span style={{ color: '#e8e3d5' }}>{m}</span>
                <span style={{ color: '#666' }}>→</span>
              </div>
            ))}
          </div>
        </div>

        {/* venues strip */}
        <div style={{ padding: 14, background: '#1a1a1c', ...rough('#f1ede222', 1) }}>
          <H size={11} font="mono" style={{ color: '#888', marginBottom: 8 }}>venues</H>
          {[
            ['Ocean Club', '64', '#7fbf8d'],
            ['The Vault', '38', '#7fbf8d'],
            ['Corner Café', 'setup', '#f4b400'],
            ['Rooftop 21', 'closed', '#666'],
          ].map(([n, cov, c]) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 0', borderBottom: '1px dashed #f1ede215' }}>
              <span style={{ width: 6, height: 6, background: c, borderRadius: '50%' }} />
              <H size={12} font="ui" style={{ color: '#f1ede2', flex: 1 }}>{n}</H>
              <H size={11} font="mono" style={{ color: '#888' }}>{cov}</H>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { RossA, RossB });
