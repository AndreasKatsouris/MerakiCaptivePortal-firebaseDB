// Dashboard, Guests, Queue, Analytics — two variants each

// ============== DASHBOARD ==============
function DashA() {
  // Editorial — warm bone, serif-ish hand, generous whitespace
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', display: 'grid', gridTemplateColumns: '180px 1fr' }}>
      <aside style={{ borderRight: '1px dashed #1a1a1a33', padding: 16, display: 'flex', flexDirection: 'column', gap: 4 }}>
        <H size={14} font="hand">Sparks</H>
        <H size={10} font="mono" style={{ color: '#888', marginBottom: 12 }}>group HQ</H>
        {['Ross', 'Today', 'Guests', 'Queue', 'Analytics', 'Food cost', 'Campaigns', 'Settings'].map((x, i) => (
          <div key={x} style={{
            padding: '6px 8px', display: 'flex', gap: 8, alignItems: 'center',
            background: i === 1 ? '#111' : 'transparent',
            color: i === 1 ? '#fff' : '#111',
            ...(i === 1 ? rough('#111', 1.2) : {}),
          }}>
            <WIcon name={['bolt','chart','users','clock','chart','forks','bell','gear'][i]} stroke={i===1?'#fff':'#111'} />
            <H size={12} font="ui" style={{ color: i===1?'#fff':'#111' }}>{x}</H>
          </div>
        ))}
      </aside>
      <main style={{ padding: 24, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <div>
            <H size={11} font="mono" style={{ color: '#888' }}>Tuesday · April 22</H>
            <H size={32} font="hand" style={{ lineHeight: 1 }}>Today at a glance</H>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <WChip>All venues ⌄</WChip>
            <WChip>Today ⌄</WChip>
            <WBtn tone="ink" size="sm">Ask Ross</WBtn>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
          {[['Revenue','$12,480','↑ 8.2%'],['Covers','316','↑ 12'],['Avg check','$39.50','↓ $1.20'],['NPS','74','↑ 3']].map(([k,v,d])=>(
            <WBox key={k} pad={12}>
              <H size={10} font="mono" style={{ color: '#888' }}>{k}</H>
              <H size={26} font="hand">{v}</H>
              <H size={11} font="mono" style={{ color: '#2f6b3a' }}>{d}</H>
            </WBox>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, flex: 1, overflow: 'hidden' }}>
          <WBox pad={14}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <H size={14} font="hand">Revenue · 30 days</H>
              <div style={{ display: 'flex', gap: 6 }}>
                <WChip>Ocean Club</WChip><WChip>Vault</WChip><WChip>Café</WChip>
              </div>
            </div>
            <WLineChart h={160} seed={11} fill="#f4b400" />
          </WBox>
          <WBox pad={14}>
            <H size={14} font="hand">Top performers</H>
            <WHR />
            {['Ocean Club · $4.8k','The Vault · $3.2k','Corner Café · $2.1k','Rooftop 21 · $1.4k'].map((x,i)=>(
              <div key={x} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: '1px dashed #1a1a1a22' }}>
                <H size={11} font="mono" style={{ color: '#888', width: 16 }}>{i+1}</H>
                <H size={12} font="ui" style={{ flex: 1 }}>{x}</H>
                <WSpark w={60} h={20} seed={i+3} />
              </div>
            ))}
          </WBox>
        </div>
      </main>
    </div>
  );
}

function DashB() {
  // Dense operator grid — top nav, many modules on one screen
  return (
    <div style={{ width: '100%', height: '100%', background: '#f4f2ea', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '10px 16px', borderBottom: '1.5px solid #111', gap: 20, background: '#fff' }}>
        <H size={14} font="hand">Sparks</H>
        {['Ross','Ops','Guests','Queue','Analytics','Food','Campaigns','Admin'].map((x,i)=>(
          <H key={x} size={12} font="mono" style={{ color: i===1?'#111':'#888', borderBottom: i===1?'2px solid #111':'none', paddingBottom: 4 }}>{x}</H>
        ))}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
          <WChip><WIcon name="search" size={11} />&nbsp;⌘K</WChip>
          <WAvatar initials="MA" />
        </div>
      </div>
      <div style={{ flex: 1, padding: 14, display: 'grid', gridTemplateColumns: 'repeat(12,1fr)', gridAutoRows: 'minmax(80px, auto)', gap: 10, overflow: 'auto' }}>
        {/* hero metric row */}
        {[['REV','$12,480','+8.2%'],['COV','316','+12'],['CHK','$39.5','-$1.2'],['COGS','31.4%','+3.4'],['STAFF','28/32','-4'],['NPS','74','+3']].map(([k,v,d])=>(
          <div key={k} style={{ gridColumn: 'span 2', padding: 10, background: '#fff', ...rough('#111',1) }}>
            <H size={9} font="mono" style={{ color: '#888' }}>{k}</H>
            <H size={20} font="hand">{v}</H>
            <H size={10} font="mono" style={{ color: d.startsWith('-')||d.includes('+3.4')?'#c0392b':'#2f6b3a' }}>{d}</H>
          </div>
        ))}
        {/* wide chart */}
        <div style={{ gridColumn: 'span 8', gridRow: 'span 2', padding: 12, background: '#fff', ...rough('#111',1) }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <H size={12} font="mono">revenue_by_venue · 30d</H>
            <H size={10} font="mono" style={{ color: '#888' }}>hourly · stacked</H>
          </div>
          <WBarChart h={150} seed={14} count={30} accent={21} />
        </div>
        <div style={{ gridColumn: 'span 4', gridRow: 'span 2', padding: 12, background: '#fff', ...rough('#111',1) }}>
          <H size={12} font="mono">queue · live</H>
          {['Ocean Club · 12 wait · 18m','Vault · 4 wait · 6m','Café · 0 wait','Rooftop · closed'].map((x,i)=>(
            <div key={x} style={{ padding: '6px 0', borderBottom: '1px dashed #1a1a1a22', display: 'flex', gap: 6 }}>
              <WIcon name="dot" stroke={i<2?'#c0392b':i===2?'#2f6b3a':'#888'} />
              <H size={11} font="ui" style={{ flex: 1 }}>{x}</H>
              <WSpark w={40} h={16} seed={i+7} />
            </div>
          ))}
        </div>
        <div style={{ gridColumn: 'span 4', padding: 12, background: '#fff', ...rough('#111',1) }}>
          <H size={12} font="mono">guests · lapsed</H>
          <H size={24} font="hand">42 VIP</H>
          <WBarChart h={40} seed={5} count={14} />
        </div>
        <div style={{ gridColumn: 'span 4', padding: 12, background: '#fff', ...rough('#111',1) }}>
          <H size={12} font="mono">food_cost · 7d</H>
          <H size={24} font="hand" style={{ color: '#c0392b' }}>31.4% ↑</H>
          <WLineChart h={40} seed={6} stroke="#c0392b" />
        </div>
        <div style={{ gridColumn: 'span 4', padding: 12, background: '#111', color: '#fff', ...rough('#111',1) }}>
          <H size={11} font="mono" style={{ color: '#aaa' }}>ross · top suggestion</H>
          <H size={14} font="hand" style={{ color: '#fff', marginTop: 4 }}>Reorder 4 SKUs (est. save $840/wk)</H>
          <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
            <WBtn tone="accent" size="sm">Review</WBtn>
            <WBtn tone="ghost" size="sm" style={{ color: '#fff', borderColor: '#fff' }}>Dismiss</WBtn>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============== GUESTS ==============
function GuestsA() {
  // Profile-first — single guest centered, Ross notes on right
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', display: 'grid', gridTemplateColumns: '220px 1fr 300px' }}>
      <aside style={{ borderRight: '1px dashed #1a1a1a33', padding: 14 }}>
        <H size={11} font="mono" style={{ color: '#888' }}>guests · 12,480</H>
        <WBox pad={8} style={{ marginTop: 8, display: 'flex', gap: 6, alignItems: 'center' }}>
          <WIcon name="search" size={12} /><H size={11} font="mono" style={{ color: '#888' }}>search name, phone</H>
        </WBox>
        <div style={{ marginTop: 10, display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {['VIP','Lapsed','New','Birthday','All'].map((x,i)=><WChip key={x} tone={i===0?'ink':'plain'}>{x}</WChip>)}
        </div>
        <div style={{ marginTop: 10 }}>
          {[
            ['EF','Elena Foster','VIP · 22 visits'],
            ['JR','James Rivera','lapsed 94d'],
            ['AP','Ava Patel','new'],
            ['MK','Marco Kim','birthday Fri'],
            ['SH','Sara Haque','VIP · 18 visits'],
            ['LB','Liam Brennan','lapsed 60d'],
          ].map(([i,n,s],idx)=>(
            <div key={n} style={{ display: 'flex', gap: 8, padding: '8px 4px', alignItems: 'center', background: idx===0?'#fff8ea':'transparent', ...(idx===0?rough('#111',1):{}) }}>
              <WAvatar initials={i} size={26} />
              <div style={{ flex: 1 }}>
                <H size={12} font="ui">{n}</H>
                <H size={10} font="mono" style={{ color: '#888' }}>{s}</H>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main style={{ padding: 24, overflow: 'auto' }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <WAvatar initials="EF" size={64} />
          <div>
            <H size={28} font="hand">Elena Foster</H>
            <H size={12} font="mono" style={{ color: '#888' }}>VIP · member since Mar 2023 · Ocean Club regular</H>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
            <WBtn size="sm">Message</WBtn>
            <WBtn size="sm">Book table</WBtn>
            <WBtn tone="ink" size="sm">Ask Ross about Elena</WBtn>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginTop: 18 }}>
          {[['Lifetime','$4,820'],['Visits','22'],['Last visit','8 days ago'],['Avg check','$219']].map(([k,v])=>(
            <WBox key={k} pad={10}><H size={10} font="mono" style={{ color: '#888' }}>{k}</H><H size={22} font="hand">{v}</H></WBox>
          ))}
        </div>

        <WBox pad={14} style={{ marginTop: 14 }}>
          <H size={14} font="hand">Visit rhythm</H>
          <WBarChart h={60} seed={12} count={24} accent={22} />
          <H size={10} font="mono" style={{ color: '#888', marginTop: 4 }}>last 24 weeks</H>
        </WBox>

        <WBox pad={14} style={{ marginTop: 14 }}>
          <H size={14} font="hand">Visit history</H>
          <WHR />
          {[
            ['Apr 14','Ocean Club','Dinner · 2 guests · $184','Duck was "incredible" (server note)'],
            ['Apr 02','Ocean Club','Dinner · 4 guests · $412','Birthday — partner'],
            ['Mar 21','The Vault','Cocktails · 2 · $96',''],
            ['Mar 08','Ocean Club','Dinner · 2 · $198',''],
          ].map(([d,v,det,n])=>(
            <div key={d} style={{ display: 'grid', gridTemplateColumns: '80px 120px 1fr', gap: 10, padding: '8px 0', borderBottom: '1px dashed #1a1a1a22' }}>
              <H size={11} font="mono" style={{ color: '#888' }}>{d}</H>
              <H size={12} font="ui">{v}</H>
              <div>
                <H size={12} font="ui">{det}</H>
                {n && <H size={11} font="hand" style={{ color: '#c0392b', marginTop: 2 }}>↳ {n}</H>}
              </div>
            </div>
          ))}
        </WBox>
      </main>

      <aside style={{ borderLeft: '1px dashed #1a1a1a33', padding: 14, background: '#f6f2e8' }}>
        <H size={11} font="mono" style={{ color: '#888' }}>ross · about elena</H>
        <WBox tone="accent" pad={10} style={{ marginTop: 6 }}>
          <H size={13} font="hand">Likely to respond to a wine tasting invite</H>
          <H size={11} font="ui" style={{ color: '#444', marginTop: 4 }}>Orders wine pairings 80% of visits. Mentioned "natural wine" twice in last 3 visits.</H>
        </WBox>
        <WBox pad={10} style={{ marginTop: 10 }}>
          <H size={12} font="hand">Preferences (learned)</H>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 6 }}>
            {['table-by-window','no-cilantro','natural wine','birthday · Oct','pet-friendly'].map(x=><WChip key={x}>{x}</WChip>)}
          </div>
        </WBox>
        <WBox pad={10} style={{ marginTop: 10 }}>
          <H size={12} font="hand">Suggested next touch</H>
          <H size={11} font="ui" style={{ color: '#444', marginTop: 4 }}>She hasn't tried the new spring menu. Draft a personal note from the chef?</H>
          <WBtn tone="ink" size="sm" style={{ marginTop: 8 }}>Draft with Ross</WBtn>
        </WBox>
      </aside>
    </div>
  );
}

function GuestsB() {
  // Segment-first — "cohort builder" board
  return (
    <div style={{ width: '100%', height: '100%', background: '#f4f2ea', padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <H size={24} font="hand">Guest segments</H>
        <H size={11} font="mono" style={{ color: '#888' }}>12,480 total · 8 active segments</H>
        <WBtn tone="ink" size="sm" style={{ marginLeft: 'auto' }}>+ New segment</WBtn>
      </div>

      {/* segment builder strip */}
      <WBox pad={12}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <H size={12} font="mono" style={{ color: '#888' }}>guests where</H>
          <WChip tone="ink">visits ≥ 5</WChip>
          <H size={11} font="mono" style={{ color: '#888' }}>AND</H>
          <WChip tone="ink">last visit &gt; 60 days</WChip>
          <H size={11} font="mono" style={{ color: '#888' }}>AND</H>
          <WChip tone="ink">lifetime spend &gt; $500</WChip>
          <WChip>+ add rule</WChip>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
            <H size={13} font="hand">→ 42 guests match</H>
            <WBtn size="sm">Save</WBtn>
            <WBtn tone="ink" size="sm">Campaign</WBtn>
          </div>
        </div>
      </WBox>

      {/* segment cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, flex: 1, overflow: 'auto' }}>
        {[
          { n: 'Lapsed VIPs', c: 42, s: '$2,180 avg LTV', h: 'Win-back draft ready', w: true, chart: 1 },
          { n: 'New this month', c: 318, s: '2.1 avg visits', h: '68% return rate', chart: 2 },
          { n: 'Birthday · this week', c: 87, s: 'celebrate soon', h: 'SMS ready', chart: 3 },
          { n: 'Weekend regulars', c: 204, s: '3+ Sat visits/mo', h: '—', chart: 4 },
          { n: 'Big spenders', c: 61, s: '$320+ avg check', h: 'VIP list?', chart: 5 },
          { n: 'First-timers (30d)', c: 156, s: '0 return yet', h: 'Follow-up?', chart: 6 },
        ].map(seg => (
          <WBox key={seg.n} pad={14} tone={seg.w ? 'accent' : 'plain'}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <H size={14} font="hand">{seg.n}</H>
              <WIcon name="users" />
            </div>
            <H size={30} font="hand" style={{ marginTop: 4 }}>{seg.c}</H>
            <H size={11} font="mono" style={{ color: '#888' }}>{seg.s}</H>
            <WBarChart h={44} seed={seg.chart} count={10} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
              <H size={11} font="hand" style={{ color: '#c0392b' }}>{seg.h}</H>
              <H size={11} font="mono" style={{ color: '#888' }}>open →</H>
            </div>
          </WBox>
        ))}
      </div>
    </div>
  );
}

// ============== QUEUE ==============
function QueueA() {
  // Live floor — visual, left panel + floor map
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', display: 'grid', gridTemplateColumns: '300px 1fr 260px' }}>
      <aside style={{ borderRight: '1px dashed #1a1a1a33', padding: 14, overflow: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <H size={20} font="hand">Waitlist</H>
          <H size={11} font="mono" style={{ color: '#c0392b' }}>12 waiting · 18m</H>
        </div>
        <WBtn tone="ink" size="sm" style={{ marginTop: 8 }}>+ Add party</WBtn>
        <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {[
            ['Rivera','4','18m','quoted 20','#fff8ea'],
            ['Chen','2','12m','','#fff'],
            ['Patel','6','8m','high chair','#fff'],
            ['Kim','2','6m','anniversary','#fff'],
            ['Nguyen','3','4m','','#fff'],
            ['Gomez','2','2m','','#fff'],
          ].map(([n,s,w,note,bg])=>(
            <div key={n} style={{ padding: 10, background: bg, ...rough('#111',1.2) }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <H size={14} font="hand">{n} · {s}</H>
                <H size={11} font="mono" style={{ color: '#c0392b' }}>{w}</H>
              </div>
              {note && <H size={10} font="mono" style={{ color: '#888' }}>{note}</H>}
              <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                <WChip>seat</WChip><WChip>ping</WChip><WChip>remove</WChip>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main style={{ padding: 18, overflow: 'hidden', position: 'relative' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <H size={24} font="hand">Ocean Club · floor</H>
          <div style={{ display: 'flex', gap: 6 }}>
            <WChip tone="ink">Main</WChip><WChip>Patio</WChip><WChip>Bar</WChip>
          </div>
        </div>
        <H size={11} font="mono" style={{ color: '#888' }}>28 tables · 18 seated · 6 open · 4 turning</H>

        {/* Sketchy floor plan */}
        <div style={{ marginTop: 14, height: 'calc(100% - 60px)', ...rough('#111',1.4), background: '#fffdf6', position: 'relative', padding: 20 }}>
          <svg viewBox="0 0 100 60" preserveAspectRatio="none" style={{ position:'absolute', inset:0, width:'100%', height:'100%' }}>
            <path d="M2,20 Q50,14 98,22" fill="none" stroke="#1a1a1a22" strokeDasharray="2 2" />
            <path d="M50,4 L50,56" stroke="#1a1a1a22" strokeDasharray="2 2" />
          </svg>
          {[
            [12,15,'T1','seated','2'],  [28,15,'T2','open',''],
            [44,15,'T3','seated','4'], [60,15,'T4','turning','—'],
            [76,15,'T5','seated','2'],
            [12,40,'T6','seated','4'], [28,40,'T7','open',''],
            [44,40,'T8','seated','6'], [60,40,'T9','seated','2'],
            [76,40,'B1','bar','3'],
          ].map(([x,y,id,st,p])=>{
            const tone = st==='seated'?'#dfeedf':st==='open'?'#fff':st==='turning'?'#fde4d6':'#fff3cc';
            return (
              <div key={id} style={{ position: 'absolute', left: `${x}%`, top: `${y}%`, transform: 'translate(-50%,-50%)', background: tone, padding: '8px 12px', ...rough('#111',1.2), textAlign: 'center', minWidth: 64 }}>
                <H size={12} font="hand">{id}</H>
                <H size={9} font="mono" style={{ color: '#666' }}>{st}{p?` · ${p}`:''}</H>
              </div>
            );
          })}
          <WNote side="right" top={100} style={{ width: 160 }}>Ross: seat Chen at T2 — 12m quote becomes 4m</WNote>
        </div>
      </main>

      <aside style={{ borderLeft: '1px dashed #1a1a1a33', padding: 14, background: '#f6f2e8' }}>
        <H size={11} font="mono" style={{ color: '#888' }}>live metrics</H>
        <WBox pad={10} style={{ marginTop: 6 }}>
          <H size={10} font="mono" style={{ color: '#888' }}>avg wait</H>
          <H size={22} font="hand">14m</H>
          <WLineChart h={30} seed={4} />
        </WBox>
        <WBox pad={10} style={{ marginTop: 10 }}>
          <H size={10} font="mono" style={{ color: '#888' }}>turn time</H>
          <H size={22} font="hand">62m</H>
          <WLineChart h={30} seed={8} />
        </WBox>
        <WBox tone="accent" pad={10} style={{ marginTop: 10 }}>
          <H size={11} font="mono" style={{ color: '#888' }}>ross suggests</H>
          <H size={13} font="hand">Park Rivera at the bar</H>
          <H size={10} font="ui" style={{ color: '#555', marginTop: 4 }}>B1 has 3 open seats. Saves ~8m wait.</H>
        </WBox>
      </aside>
    </div>
  );
}

function QueueB() {
  // Timeline / Gantt view
  return (
    <div style={{ width: '100%', height: '100%', background: '#f4f2ea', padding: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <H size={24} font="hand">Service timeline</H>
          <H size={11} font="mono" style={{ color: '#888' }}>Ocean Club · Tue 6:00–11:00 pm</H>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <WChip tone="ink">Tonight</WChip><WChip>Tomorrow</WChip><WChip>Week</WChip>
        </div>
      </div>

      <WBox pad={12} style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {/* hour ruler */}
        <div style={{ display: 'grid', gridTemplateColumns: '100px repeat(10,1fr)', gap: 0, borderBottom: '1.2px solid #111' }}>
          <H size={10} font="mono" style={{ color: '#888' }}>table</H>
          {['6','6:30','7','7:30','8','8:30','9','9:30','10','10:30'].map(h=>(
            <H key={h} size={10} font="mono" style={{ color: '#888', borderLeft: '1px dashed #1a1a1a33', padding: '2px 6px' }}>{h}</H>
          ))}
        </div>
        {/* rows */}
        {[
          ['T1 · 2-top', [[0,1.5,'Chen','done'],[2,2,'Rivera','active'],[4.5,1.5,'Kim','upcoming']]],
          ['T2 · 2-top', [[0.5,2,'Patel','done'],[3,2,'Foster','active'],[5.5,1.5,'—','hold']]],
          ['T3 · 4-top', [[0,2.5,'Nguyen','done'],[3,3,'Haque party','active']]],
          ['T4 · 4-top', [[1,2,'Gomez','done'],[3.5,2.5,'Brennan','active'],[6.5,1,'—','hold']]],
          ['T5 · 2-top', [[0,1.5,'Park','done'],[2,2,'Singh','active'],[4.5,2,'—','upcoming']]],
          ['T6 · 6-top', [[0.5,3,'Adler party','done'],[4,3,'Rivera+2','active']]],
          ['B1 · bar 4', [[0,1,'—','hold'],[1.5,1,'walk-in','done'],[3,1.5,'Chen','active'],[5,2,'Waitlist pool','upcoming']]],
        ].map(([label, blocks], ri)=>(
          <div key={ri} style={{ display: 'grid', gridTemplateColumns: '100px 1fr', borderBottom: '1px dashed #1a1a1a22', minHeight: 44 }}>
            <H size={11} font="ui" style={{ padding: '10px 4px', color: '#444' }}>{label}</H>
            <div style={{ position: 'relative' }}>
              {/* 10 col grid */}
              <div style={{ position: 'absolute', inset: 0, display: 'grid', gridTemplateColumns: 'repeat(10,1fr)' }}>
                {Array.from({length:10}).map((_,i)=><div key={i} style={{ borderLeft: '1px dashed #1a1a1a11' }} />)}
              </div>
              {blocks.map(([start, dur, label, st], bi)=>{
                const tone = st==='done'?{bg:'#e3e0d6',border:'#888'}:st==='active'?{bg:'#fff3cc',border:'#111'}:st==='upcoming'?{bg:'#fff',border:'#111'}:{bg:'#fde4d6',border:'#c0392b'};
                return (
                  <div key={bi} style={{ position: 'absolute', left: `${(start/5)*100}%`, width: `${(dur/5)*100}%`, top: 6, bottom: 6, background: tone.bg, padding: '2px 6px', ...rough(tone.border, 1.1), display: 'flex', alignItems: 'center', overflow: 'hidden' }}>
                    <H size={11} font="ui" style={{ whiteSpace: 'nowrap' }}>{label}</H>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        <div style={{ display: 'flex', gap: 10, marginTop: 10, fontFamily: WF_FONTS.mono, fontSize: 11, color: '#666' }}>
          <span><span style={{ display:'inline-block', width:10, height:10, background:'#e3e0d6', marginRight:4 }}/>done</span>
          <span><span style={{ display:'inline-block', width:10, height:10, background:'#fff3cc', marginRight:4 }}/>active</span>
          <span><span style={{ display:'inline-block', width:10, height:10, background:'#fff', border:'1px solid #111', marginRight:4 }}/>upcoming</span>
          <span><span style={{ display:'inline-block', width:10, height:10, background:'#fde4d6', marginRight:4 }}/>gap · Ross: fill?</span>
        </div>
      </WBox>
    </div>
  );
}

// ============== ANALYTICS ==============
function AnalyticsA() {
  // Narrative / editorial
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', overflow: 'auto', padding: '30px 40px' }}>
      <H size={11} font="mono" style={{ color: '#888' }}>weekly brief · week 17 · apr 14–20</H>
      <H size={44} font="hand" style={{ lineHeight: 1, maxWidth: 700 }}>A strong week, with one warning.</H>
      <H size={14} font="ui" style={{ color: '#444', marginTop: 10, maxWidth: 620 }}>
        Revenue up 8.2% across the group — Ocean Club and The Vault carried. Food cost slipped 3.4pp at Ocean Club; the rest held. Here's what Ross noticed, and what we suggest next.
      </H>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24, marginTop: 30 }}>
        <WBox pad={18}>
          <H size={18} font="hand">Revenue · 4 venues</H>
          <WLineChart h={180} seed={13} fill="#f4b400" />
          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            {['Ocean Club','Vault','Café','Rooftop'].map((n,i)=>(
              <div key={n} style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                <span style={{ width: 14, height: 2, background: ['#111','#888','#c0392b','#f4b400'][i] }} />
                <H size={11} font="mono">{n}</H>
              </div>
            ))}
          </div>
        </WBox>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[['Total','$86,420','↑ 8.2%'],['Covers','2,184','↑ 4.1%'],['Avg check','$39.57','↑ $1.80'],['Cost %','29.8%','↑ 1.1pp']].map(([k,v,d])=>(
            <WBox key={k} pad={10}>
              <H size={10} font="mono" style={{ color: '#888' }}>{k}</H>
              <H size={24} font="hand">{v}</H>
              <H size={11} font="mono" style={{ color: d.includes('pp')?'#c0392b':'#2f6b3a' }}>{d}</H>
            </WBox>
          ))}
        </div>
      </div>

      <H size={22} font="hand" style={{ marginTop: 30 }}>What Ross noticed</H>
      <WHR />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, marginTop: 10 }}>
        {[
          ['A','Saturday patio drove +$6.2k','Weather + the patio promo compounded. Repeat next weekend?'],
          ['B','Wine attach rose 14%','New sommelier picks on the menu correlate. Expand pairings?'],
          ['C','Ocean Club food cost drift','Protein line +4pp for 5 days. Supplier changed?'],
        ].map(([k,t,d])=>(
          <WBox key={k} pad={14}>
            <H size={42} font="hand" style={{ color: '#f4b400' }}>{k}</H>
            <H size={15} font="hand">{t}</H>
            <H size={12} font="ui" style={{ color: '#444', marginTop: 4 }}>{d}</H>
            <WBtn tone="ink" size="sm" style={{ marginTop: 10 }}>Open brief →</WBtn>
          </WBox>
        ))}
      </div>

      <H size={22} font="hand" style={{ marginTop: 30 }}>Forecast · next 7 days</H>
      <WBox pad={14} style={{ marginTop: 10 }}>
        <WLineChart h={120} seed={16} stroke="#111" />
        <H size={11} font="mono" style={{ color: '#888', marginTop: 6 }}>dashed = forecast · shaded = 80% CI · Sat projected $16.2k</H>
      </WBox>
    </div>
  );
}

function AnalyticsB() {
  // Dashboard — filters left, dense grid
  return (
    <div style={{ width: '100%', height: '100%', background: '#f4f2ea', display: 'grid', gridTemplateColumns: '220px 1fr' }}>
      <aside style={{ borderRight: '1px dashed #1a1a1a33', padding: 14, fontFamily: WF_FONTS.ui, fontSize: 12 }}>
        <H size={13} font="hand">Filters</H>
        <WHR />
        {[
          ['date','Last 30 days ⌄'],
          ['venues','All 4 ⌄'],
          ['daypart','All ⌄'],
          ['guest type','All ⌄'],
          ['compare','vs. prev period'],
        ].map(([k,v])=>(
          <div key={k} style={{ padding: '8px 0' }}>
            <H size={10} font="mono" style={{ color: '#888' }}>{k}</H>
            <WBox pad={6} style={{ marginTop: 4 }}><H size={12} font="ui">{v}</H></WBox>
          </div>
        ))}
        <WBtn tone="ink" size="sm" style={{ marginTop: 6 }}>Save view</WBtn>

        <H size={13} font="hand" style={{ marginTop: 20 }}>Saved reports</H>
        <WHR />
        {['Weekend performance','Lapsed-guest impact','Food-cost by venue','Staff vs. revenue','Menu items · 80/20'].map(x=>(
          <div key={x} style={{ padding: '6px 0', display: 'flex', gap: 6, alignItems: 'center' }}>
            <WIcon name="chart" />
            <H size={12} font="ui">{x}</H>
          </div>
        ))}
      </aside>

      <main style={{ padding: 16, overflow: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <H size={22} font="hand">Analytics · 30d</H>
          <div style={{ display: 'flex', gap: 6 }}>
            <WChip>export</WChip><WChip>share</WChip><WBtn tone="ink" size="sm">Ask Ross</WBtn>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginTop: 10 }}>
          {[['Revenue','$342k','+8.2%'],['Covers','9,820','+4.1%'],['Avg check','$39.5','+$1.8'],['Food cost','29.8%','+1.1pp']].map(([k,v,d])=>(
            <WBox key={k} pad={10}>
              <H size={10} font="mono" style={{ color: '#888' }}>{k}</H>
              <H size={22} font="hand">{v}</H>
              <H size={11} font="mono" style={{ color: d.includes('pp')?'#c0392b':'#2f6b3a' }}>{d}</H>
              <WSpark w="100%" h={22} seed={k.length} />
            </WBox>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 10, marginTop: 10 }}>
          <WBox pad={12}>
            <H size={12} font="mono" style={{ color: '#888' }}>revenue by venue · daily</H>
            <WBarChart h={140} seed={20} count={30} accent={18} />
          </WBox>
          <WBox pad={12}>
            <H size={12} font="mono" style={{ color: '#888' }}>cohort retention</H>
            {/* heat grid */}
            <div style={{ marginTop: 6, display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 2 }}>
              {Array.from({length: 48}).map((_,i)=>{
                const op = 0.15 + ((i*37)%100)/150;
                return <div key={i} style={{ height: 18, background: `rgba(17,17,17,${op.toFixed(2)})` }} />;
              })}
            </div>
            <H size={10} font="mono" style={{ color: '#888', marginTop: 4 }}>rows = cohort · cols = week</H>
          </WBox>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginTop: 10 }}>
          <WBox pad={12}>
            <H size={12} font="mono" style={{ color: '#888' }}>menu · top 10</H>
            {['Duck confit · 412','Ribeye · 318','House burger · 289','Caesar · 251','Oysters · 202'].map(x=>(
              <div key={x} style={{ display: 'flex', gap: 6, padding: '3px 0', alignItems: 'center' }}>
                <H size={11} font="ui" style={{ flex: 1 }}>{x.split('·')[0]}</H>
                <div style={{ width: '40%', height: 8, background: '#e8e4d6', ...rough('#111', 1) }}>
                  <div style={{ width: `${60 + Math.random()*30}%`, height: '100%', background: '#111' }} />
                </div>
                <H size={10} font="mono" style={{ color: '#888' }}>{x.split('·')[1]}</H>
              </div>
            ))}
          </WBox>
          <WBox pad={12}>
            <H size={12} font="mono" style={{ color: '#888' }}>hourly · heatmap</H>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(24, 1fr)', gap: 1, marginTop: 6 }}>
              {Array.from({length: 7*24}).map((_,i)=>{
                const h = i%24;
                const base = (h>=18 && h<=21) ? 0.8 : h>=12 && h<=14 ? 0.5 : 0.15;
                const op = base + (((i*13)%50)/200);
                return <div key={i} style={{ height: 12, background: `rgba(17,17,17,${op.toFixed(2)})` }} />;
              })}
            </div>
            <H size={10} font="mono" style={{ color: '#888', marginTop: 4 }}>mon → sun · 0 → 23</H>
          </WBox>
          <WBox pad={12} tone="ink" style={{ color: '#fff' }}>
            <H size={11} font="mono" style={{ color: '#aaa' }}>ross · this week</H>
            <H size={15} font="hand" style={{ color: '#fff' }}>3 insights worth opening</H>
            {['Wine attach +14% · expand pairings?','Sat patio beat forecast +22%','Protein cost drift — supplier?'].map(x=>(
              <div key={x} style={{ display: 'flex', gap: 6, padding: '4px 0', borderTop: '1px dashed #555' }}>
                <WIcon name="arrow" stroke="#fff" />
                <H size={11} font="ui" style={{ color: '#fff' }}>{x}</H>
              </div>
            ))}
          </WBox>
        </div>
      </main>
    </div>
  );
}

// ============== ROSS MOBILE ==============
function RossMobile() {
  return (
    <div style={{ width: '100%', height: '100%', background: '#faf7ef', padding: 14, display: 'flex', flexDirection: 'column', gap: 10, fontFamily: WF_FONTS.ui }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <H size={10} font="mono">9:14</H>
        <div style={{ display: 'flex', gap: 4 }}>
          <H size={10} font="mono">••• wifi ▮</H>
        </div>
      </div>
      <div>
        <H size={10} font="mono" style={{ color: '#888' }}>ross · tuesday</H>
        <H size={24} font="hand" style={{ lineHeight: 1.05 }}>Morning, Maya.</H>
        <H size={12} font="ui" style={{ color: '#555' }}>3 things worth a look.</H>
      </div>
      <WBox tone="accent" pad={10}>
        <H size={10} font="mono" style={{ color: '#888' }}>urgent</H>
        <H size={14} font="hand">Ocean Club food cost spike</H>
        <WLineChart h={32} seed={9} stroke="#c0392b" />
        <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
          <WBtn tone="ink" size="sm">Open</WBtn><WBtn size="sm">Why?</WBtn>
        </div>
      </WBox>
      <WBox pad={10}>
        <H size={10} font="mono" style={{ color: '#888' }}>guest</H>
        <H size={14} font="hand">42 VIPs lapsed — draft ready</H>
      </WBox>
      <WBox pad={10}>
        <H size={10} font="mono" style={{ color: '#888' }}>win</H>
        <H size={14} font="hand">Weekend forecast +18%</H>
      </WBox>
      <div style={{ flex: 1 }} />
      <WBox tone="ink" pad={10} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <H size={12} font="hand" style={{ color: '#fff' }}>Ask Ross</H>
        <H size={12} font="mono" style={{ color: '#888', flex: 1 }}>type or hold to talk…</H>
        <WIcon name="bolt" stroke="#f4b400" size={16} />
      </WBox>
      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '6px 0', borderTop: '1px dashed #1a1a1a33' }}>
        {['bolt','chart','users','clock','user'].map((x,i)=>(
          <div key={x} style={{ padding: 4, ...(i===0?rough('#111',1):{}) }}><WIcon name={x} /></div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { DashA, DashB, GuestsA, GuestsB, QueueA, QueueB, AnalyticsA, AnalyticsB, RossMobile });
