// Shared wireframe kit — sketchy but readable
// Exposes primitives on window for all screen files.

const WF_FONTS = {
  hand: "'Caveat', 'Kalam', cursive",
  ui: "'Architects Daughter', 'Kalam', cursive",
  mono: "'JetBrains Mono', ui-monospace, monospace",
};

// Rough border helper — double-stroke via box-shadow to feel hand-drawn
const rough = (color = '#111', width = 1.5) => ({
  border: `${width}px solid ${color}`,
  boxShadow: `1px 1px 0 ${color}22, inset 0 0 0 0.5px ${color}33`,
  borderRadius: '3px 6px 3px 5px',
});

// Wiggle (for a hand-drawn feel on straight lines) via SVG filter defined once
function WFDefs() {
  return (
    <svg width="0" height="0" style={{ position: 'absolute' }}>
      <defs>
        <filter id="wf-wiggle" x="-5%" y="-5%" width="110%" height="110%">
          <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed="4" />
          <feDisplacementMap in="SourceGraphic" scale="1.3" />
        </filter>
        <filter id="wf-wiggle-strong">
          <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2" seed="7" />
          <feDisplacementMap in="SourceGraphic" scale="2.2" />
        </filter>
      </defs>
    </svg>
  );
}

// Sketchy box
function WBox({ children, style, pad = 12, tone = 'plain', className = '', ...rest }) {
  const tones = {
    plain: { bg: '#fff', border: '#1a1a1a' },
    dim:   { bg: '#f6f4ef', border: '#1a1a1a' },
    ink:   { bg: '#111', border: '#111', color: '#fff' },
    accent:{ bg: '#fff8ea', border: '#1a1a1a' },
    warn:  { bg: '#fff1ec', border: '#1a1a1a' },
    good:  { bg: '#eef6ef', border: '#1a1a1a' },
  }[tone] || { bg: '#fff', border: '#1a1a1a' };
  return (
    <div className={className}
      style={{
        background: tones.bg, color: tones.color || '#111',
        padding: pad, ...rough(tones.border, 1.5),
        ...style,
      }} {...rest}>
      {children}
    </div>
  );
}

// Hand-written text
function H({ children, size = 14, weight = 400, font = 'ui', style, tag = 'div' }) {
  const Tag = tag;
  return (
    <Tag style={{
      fontFamily: WF_FONTS[font] || WF_FONTS.ui,
      fontSize: size, fontWeight: weight, lineHeight: 1.2,
      letterSpacing: font === 'mono' ? 0 : 0.2,
      ...style,
    }}>{children}</Tag>
  );
}

// Wavy divider
function WHR({ color = '#1a1a1a', style }) {
  return (
    <svg viewBox="0 0 200 6" preserveAspectRatio="none"
      style={{ width: '100%', height: 6, display: 'block', ...style }}>
      <path d="M0,3 Q20,0 40,3 T80,3 T120,3 T160,3 T200,3"
        fill="none" stroke={color} strokeWidth="1.2" />
    </svg>
  );
}

// Placeholder rectangle with a diagonal slash to denote "image/chart area"
function WPlaceholder({ label = 'img', h = 80, style, dense = false }) {
  return (
    <div style={{
      position: 'relative', height: h, width: '100%',
      background: 'repeating-linear-gradient(135deg, #f2efe8 0 6px, #faf8f3 6px 12px)',
      ...rough('#1a1a1a', 1.2),
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      ...style,
    }}>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} preserveAspectRatio="none">
        <line x1="0" y1="0" x2="100%" y2="100%" stroke="#1a1a1a22" strokeWidth="1" />
        <line x1="100%" y1="0" x2="0" y2="100%" stroke="#1a1a1a22" strokeWidth="1" />
      </svg>
      <H size={dense ? 10 : 12} font="mono" style={{ background: '#faf8f3', padding: '2px 6px', border: '1px dashed #1a1a1a66' }}>
        {label}
      </H>
    </div>
  );
}

// Sketchy button
function WBtn({ children, tone = 'plain', size = 'md', style }) {
  const t = {
    plain: { bg: '#fff', fg: '#111' },
    ink:   { bg: '#111', fg: '#fff' },
    accent:{ bg: '#f4b400', fg: '#111' },
    ghost: { bg: 'transparent', fg: '#111' },
  }[tone];
  const s = { sm: { py: 4, px: 10, fs: 12 }, md: { py: 6, px: 14, fs: 13 }, lg: { py: 10, px: 18, fs: 15 } }[size];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: `${s.py}px ${s.px}px`, background: t.bg, color: t.fg,
      fontFamily: WF_FONTS.ui, fontSize: s.fs,
      ...rough(t.fg === '#fff' ? '#111' : '#111', 1.4),
      ...style,
    }}>{children}</span>
  );
}

// Sketchy line chart
function WLineChart({ h = 80, seed = 1, stroke = '#111', fill = null, dashed = false, points = 22 }) {
  // pseudo-random with seed
  let s = seed * 9301 + 49297;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const pts = [];
  let y = 0.5;
  for (let i = 0; i < points; i++) {
    y += (rnd() - 0.48) * 0.22;
    y = Math.max(0.08, Math.min(0.92, y));
    pts.push([i / (points - 1), y]);
  }
  const toCoord = ([x, y]) => `${(x * 100).toFixed(1)},${(y * 100).toFixed(1)}`;
  const path = 'M ' + pts.map(toCoord).join(' L ');
  const filled = fill ? `${path} L 100,100 L 0,100 Z` : null;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height: h, filter: 'url(#wf-wiggle)' }}>
      {filled && <path d={filled} fill={fill} opacity="0.35" />}
      <path d={path} fill="none" stroke={stroke} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={dashed ? '3 2' : undefined} />
    </svg>
  );
}

// Sketchy bar chart
function WBarChart({ h = 80, seed = 2, count = 12, accent = -1, color = '#111' }) {
  let s = seed * 9301 + 49297;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const bars = Array.from({ length: count }, () => 0.25 + rnd() * 0.7);
  const gap = 2;
  const bw = (100 - gap * (count - 1)) / count;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ width: '100%', height: h, filter: 'url(#wf-wiggle)' }}>
      {bars.map((v, i) => (
        <rect key={i}
          x={i * (bw + gap)} y={100 - v * 100} width={bw} height={v * 100}
          fill={i === accent ? '#f4b400' : color} opacity={i === accent ? 0.95 : 0.85} />
      ))}
    </svg>
  );
}

// Sketchy donut
function WDonut({ size = 80, pct = 0.62, color = '#111' }) {
  const r = 36, c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: 'url(#wf-wiggle)' }}>
      <circle cx="50" cy="50" r={r} fill="none" stroke="#1a1a1a33" strokeWidth="10" />
      <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="10"
        strokeDasharray={`${(c * pct).toFixed(1)} ${c.toFixed(1)}`}
        strokeLinecap="round" transform="rotate(-90 50 50)" />
    </svg>
  );
}

// Sparkline
function WSpark({ h = 24, w = 80, seed = 3, stroke = '#111' }) {
  return <WLineChart h={h} seed={seed} stroke={stroke} points={14} />;
}

// Pill / chip
function WChip({ children, tone = 'plain', style }) {
  const t = {
    plain: { bg: '#fff', fg: '#111' },
    ink:   { bg: '#111', fg: '#fff' },
    accent:{ bg: '#fff3cc', fg: '#111' },
    good:  { bg: '#dfeedf', fg: '#111' },
    warn:  { bg: '#fde4d6', fg: '#111' },
    ghost: { bg: 'transparent', fg: '#111' },
  }[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', background: t.bg, color: t.fg,
      fontFamily: WF_FONTS.ui, fontSize: 11,
      ...rough('#111', 1),
      ...style,
    }}>{children}</span>
  );
}

// Margin note (annotation)
function WNote({ children, side = 'right', top = 20, style }) {
  const L = side === 'left';
  return (
    <div style={{
      position: 'absolute', top,
      [L ? 'right' : 'left']: '100%',
      [L ? 'marginRight' : 'marginLeft']: 12,
      width: 150, pointerEvents: 'none',
      ...style,
    }}>
      <svg width="28" height="18" style={{ display: 'block', transform: L ? 'scaleX(-1)' : 'none' }}>
        <path d="M2,9 Q14,2 26,9" fill="none" stroke="#c0392b" strokeWidth="1.2" />
        <path d="M22,5 L26,9 L21,11" fill="none" stroke="#c0392b" strokeWidth="1.2" />
      </svg>
      <H size={13} font="hand" style={{ color: '#c0392b', transform: 'rotate(-1deg)' }}>
        {children}
      </H>
    </div>
  );
}

// Avatar circle
function WAvatar({ initials = 'A', size = 28, tone = '#e9e4d8' }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: size, height: size, background: tone,
      borderRadius: '50%',
      border: '1.2px solid #111',
      fontFamily: WF_FONTS.ui, fontSize: size * 0.42,
    }}>{initials}</span>
  );
}

// Simple SVG icon glyphs (rough, one stroke)
function WIcon({ name = 'dot', size = 14, stroke = '#111' }) {
  const props = { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', stroke, strokeWidth: 1.4, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    dot: <circle cx="8" cy="8" r="3" />,
    search: <><circle cx="7" cy="7" r="4" /><path d="M10.5 10.5 L14 14" /></>,
    bolt: <path d="M9 2 L4 9 H8 L7 14 L12 7 H8 Z" />,
    bell: <><path d="M4 11 H12 L11 9 V7 A3 3 0 0 0 5 7 V9 Z" /><path d="M7 12 A1 1 0 0 0 9 12" /></>,
    user: <><circle cx="8" cy="6" r="2.5" /><path d="M3 14 C3 11 5 10 8 10 C11 10 13 11 13 14" /></>,
    users: <><circle cx="6" cy="6" r="2" /><circle cx="11" cy="7" r="1.6" /><path d="M2 13 C2 11 4 10 6 10 C8 10 10 11 10 13" /><path d="M11 13 C11 11.5 12.5 11 14 11.5" /></>,
    plus: <><path d="M8 3 V13" /><path d="M3 8 H13" /></>,
    chart: <><path d="M2 13 H14" /><path d="M4 11 V8" /><path d="M7 11 V5" /><path d="M10 11 V7" /><path d="M13 11 V3" /></>,
    cal:   <><rect x="2.5" y="3" width="11" height="10" /><path d="M2.5 6 H13.5" /><path d="M6 2 V4" /><path d="M10 2 V4" /></>,
    forks: <><path d="M4 2 V14" /><path d="M4 8 H10 V14" /></>,
    star:  <path d="M8 2 L9.5 6 L13.5 6 L10.5 8.5 L11.5 12.5 L8 10 L4.5 12.5 L5.5 8.5 L2.5 6 L6.5 6 Z" />,
    gear:  <><circle cx="8" cy="8" r="2.2" /><path d="M8 2 V4 M8 12 V14 M2 8 H4 M12 8 H14 M3.5 3.5 L5 5 M11 11 L12.5 12.5 M3.5 12.5 L5 11 M11 5 L12.5 3.5" /></>,
    menu:  <><path d="M3 5 H13" /><path d="M3 8 H13" /><path d="M3 11 H13" /></>,
    arrow: <><path d="M3 8 H13" /><path d="M10 5 L13 8 L10 11" /></>,
    check: <path d="M3 8 L6 11 L13 4" />,
    clock: <><circle cx="8" cy="8" r="5.5" /><path d="M8 5 V8 L10 9.5" /></>,
    tray:  <><path d="M2 10 V13 H14 V10" /><path d="M5 10 L6 6 H10 L11 10" /></>,
    route: <><circle cx="4" cy="4" r="1.5" /><circle cx="12" cy="12" r="1.5" /><path d="M5.5 4 H10 A3 3 0 0 1 10 10 H6 A3 3 0 0 0 6 14" /></>,
    spark: <path d="M2 10 Q5 4 8 9 T14 5" />,
    fire:  <path d="M8 2 C9 5 12 6 11 10 C10.5 12.5 9 14 8 14 C7 14 5.5 12.5 5 10 C4.5 7.5 6 7 7 5 C7.5 4 7.5 3 8 2 Z" />,
  };
  return <svg {...props}>{paths[name] || paths.dot}</svg>;
}

Object.assign(window, {
  WF_FONTS, rough, WFDefs, WBox, H, WHR, WPlaceholder,
  WBtn, WLineChart, WBarChart, WDonut, WSpark, WChip,
  WNote, WAvatar, WIcon,
});
